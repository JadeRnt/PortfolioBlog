open module projet {
    requires javafx.base;
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
    requires org.bouncycastle.provider;
    requires java.sql;
    requires mysql.connector.java;
    requires org.json;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;
}
