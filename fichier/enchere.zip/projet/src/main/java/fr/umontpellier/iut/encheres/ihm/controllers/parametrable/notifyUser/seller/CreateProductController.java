package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.seller;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserController;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Vendeur;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.CreateProduct;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import java.util.Map;
import java.util.UUID;

public class CreateProductController extends NotifyUserController {

    @FXML
    private TextArea description;

    @FXML
    private  TextField title;


    private Session session;

    @FXML
    public void createProduct() {
        String productIdText = UUID.randomUUID().toString();
        String descriptionText = description.getText();
        CreateProduct createProduct = new CreateProduct(new Produit((Vendeur) session.getConnectedUser(), productIdText, descriptionText, title.getText()));
        session.getSocket().sendData(createProduct);
    }


    @Override
    public void setParameters(Map<String, Object> parameters) {
        session = (Session) parameters.get("session");
    }

    @Override
    public Session getSession() {
        return session;
    }

    public void onProductCreated(CreateProduct productCreated) {
        if (productCreated.isCreated()){
            setAlertMessage("Le produit a été crée");
            description.setText("");
            title.setText("");
        }
        else {
            setAlertMessage("Il y a eu une erreur, le produit n'a pas été crée");
        }

    }
}
