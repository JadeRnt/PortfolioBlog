//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.repositories;

import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.utils.DBUtils;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;
import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.api.EntityRepository;

public class EntityRepositoryDatabase<T> implements EntityRepository<T> {
    private final Class<T> type;

    public EntityRepositoryDatabase(Class<T> type) {
        this.type = type;
    }

    public List<T> findAll() {
        Session session = DBUtils.getSession();
        CriteriaBuilder builder = session.getCriteriaBuilder();
        CriteriaQuery<T> criteria = builder.createQuery(this.type);
        criteria.from(this.type);
        List<T> result = session.createQuery(criteria).getResultList();
        session.close();
        return result;
    }

    public T findByID(Object id) {
        Session session = DBUtils.getSession();
        T result = session.get(this.type, id);
        session.close();
        return result;
    }

    public void create(T entity) {
        Session session = DBUtils.getSession();
        Transaction tx = session.beginTransaction();
        session.persist(entity);
        session.flush();
        tx.commit();
        session.close();
    }

    public void update(T entity) {
        Session session = DBUtils.getSession();
        Transaction tx = session.beginTransaction();
        session.merge(entity);
        session.flush();
        tx.commit();
        session.close();
    }

    public void delete(T entity) {
        Session session = DBUtils.getSession();
        Transaction tx = session.beginTransaction();
        session.remove(entity);
        session.flush();
        tx.commit();
        session.close();
    }

    public void deleteById(Object id) {
        T entity = this.findByID(id);
        if (entity != null) {
            this.delete(entity);
        }

    }

    public Class<T> getType() {
        return this.type;
    }

    public T findById(Object[] compositeKey) {
        Session session = DBUtils.getSession();
        try {
            // Construct a composite key object (assuming your composite key is an embeddable type)
            T keyObject = constructCompositeKey(compositeKey);
            T result = session.get(this.type, keyObject);
            return result;
        } finally {
            session.close();
        }
    }

    // Helper method to construct a composite key object
    private T constructCompositeKey(Object[] keyValues) {
        try {
            // Assuming the composite key type has a constructor that takes an array of values
            // You might need to adjust this based on the actual structure of your composite key
            return this.type.getDeclaredConstructor(Object[].class).newInstance((Object) keyValues);
        } catch (Exception e) {
            throw new RuntimeException("Error constructing composite key", e);
        }
    }
}
