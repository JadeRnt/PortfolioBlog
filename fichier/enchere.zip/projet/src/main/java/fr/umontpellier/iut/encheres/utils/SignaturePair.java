package fr.umontpellier.iut.encheres.utils;

import fr.umontpellier.iut.encheres.reseau.data.Data;

import java.security.PrivateKey;
import java.security.PublicKey;

public class SignaturePair implements Data {

    private final PrivateKey privateKey;
    private final PublicKey publicKey;

    public SignaturePair(PrivateKey privateKey, PublicKey publicKey) {
        this.privateKey = privateKey;
        this.publicKey = publicKey;
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    public PublicKey getPublicKey() {
        return publicKey;
    }
}
