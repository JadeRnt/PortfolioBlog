package fr.umontpellier.iut.encheres.ihm.controllers.parametrable;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.UserViewController;
import fr.umontpellier.iut.encheres.ihm.listeners.Listener;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.LogOut;
import javafx.fxml.FXML;
import java.util.Map;

public class LogOutController implements ParametrableController {

    private Session session;
    private Service<Listener> service;

    @Override
    public void setParameters(Map<String, Object> parameters) {

        session = (Session) parameters.get("session");
        service = (Service<Listener>) parameters.get("service");
    }

    @Override
    public Session getSession() {
        return session;
    }


    @FXML
    public void deconnectUser() {
        session.getSocket().sendData(new LogOut());
        session.getSocket().close();
        Scenes.removeAllScenes();
        service.stopService();
        (new UserViewController()).loadLoginView();
    }

}
