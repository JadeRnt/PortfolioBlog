package fr.umontpellier.iut.encheres.utils;

import org.bouncycastle.util.encoders.Base64;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;

public class SignatureUtils {
    public static String signerDonnees(String donnees, PrivateKey clePrivee) {
        try{
            Signature signature = Signature.getInstance("RSA/ECB/PKCS1Padding");
            signature.initSign(clePrivee);
            signature.update(donnees.getBytes());
            byte[] signatureBytes = signature.sign();
            return Base64.toBase64String(signatureBytes);
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public static boolean verifierSignature(String signature, PublicKey clePublique){
        try{
            Signature sign = Signature.getInstance("RSA/ECB/PKCS1Padding");
            sign.initVerify(clePublique);
            sign.update(signature.getBytes());
            return sign.verify(Base64.decode(signature));
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return false;
    }
}
