package fr.umontpellier.iut.encheres.ihm;

import fr.umontpellier.iut.encheres.ihm.listeners.Listener;
import javafx.concurrent.ScheduledService;
import javafx.concurrent.Task;

import java.util.ArrayList;
import java.util.List;

public class Service<ControllerType extends Listener> extends ScheduledService<Void> {

    private ControllerType controller;

    private boolean started;

    @Override
    protected Task<Void> createTask() {
        return new Task<>() {
            @Override
            protected Void call() {
                notifyUser();
                return null;
            }
        };
    }

    public boolean isStarted() {
        return started;
    }

    public void setStarted() {
        started = true;
    }


    public ControllerType getController() {
        return controller;
    }

    public void setController(ControllerType controller) {
        this.controller = controller;
    }

    public void notifyUser() {
        controller.notifyUser(this);
    }

    public void stopService() {
        cancel();
    }

}
