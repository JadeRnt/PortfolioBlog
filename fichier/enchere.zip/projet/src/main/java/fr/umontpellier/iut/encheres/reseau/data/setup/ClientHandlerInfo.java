package fr.umontpellier.iut.encheres.reseau.data.setup;

import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.reseau.data.Message;

import java.util.List;

public class ClientHandlerInfo extends HandlerInfo {

    private final List<Offre> offersMade;
    private final List<Enchere> openAuctions;
    private final List<Message> clientResults;

    public ClientHandlerInfo(String clientID, Utilisateur connectedUser,
                             List<Offre> offersMade, List<Enchere> currentOpenAuctions,
                             List<Message> clientResults) {
        super(clientID, connectedUser);
        this.offersMade = offersMade;
        openAuctions = currentOpenAuctions;
        this.clientResults = clientResults;
    }

    public List<Offre> getOffersMade() {
        return offersMade;
    }

    public List<Enchere> getOpenAuctions() {
        return openAuctions;
    }

    public List<Message> getClientResults() {
        return clientResults;
    }
}
