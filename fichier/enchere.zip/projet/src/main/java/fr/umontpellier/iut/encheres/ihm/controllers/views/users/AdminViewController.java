package fr.umontpellier.iut.encheres.ihm.controllers.views.users;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.ConfigureMainController;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.metier.Produit;

import java.util.HashMap;
import java.util.Map;

public class AdminViewController extends ConfigureMainController {

    public void loadAdminView(Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        loadMainView("/views/admin/productViewAdmin.fxml", parameters);
    }

    public void loadStartBiddingView(Produit product, Session session) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("session", session);
        parameters.put("produit", product);
        Scenes.uploadCenterView(product.getIdProduit(), "/views/admin/startBiddingView.fxml", parameters);
    }
}
