package fr.umontpellier.iut.encheres.metier;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.Objects;

public class Offre extends AbstractDataObject {

    private Client client;

    private Produit product;

    private String montant;
    private LocalDateTime time;

    public Offre(Client client, Produit product, String montant) {
        this.client = client;
        this.product = product;
        this.montant = montant;
    }

    public Offre(Client client, Produit product, String montant, LocalDateTime time) {
        this.client = client;
        this.product = product;
        this.montant = montant;
        this.time = time;
    }

    public Offre() {

    }

    public Client getClient() {
        return client;
    }

    public Produit getProduct() {
        return product;
    }

    public String getMontant() {
        return montant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Offre offre = (Offre) o;
        return Objects.equals(montant, offre.montant);
    }

    @Override
    public int hashCode() {
        return Objects.hash(montant);
    }

    public LocalDateTime getTime() {
        return time;
    }
}
