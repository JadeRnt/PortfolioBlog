package fr.umontpellier.iut.encheres.stockage.Local.Serveur;

import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.data.AuctionEnded;
import fr.umontpellier.iut.encheres.reseau.services.ConnectedCheck;

import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class OpenAuctions {

    private final Set<Enchere> auctions = new HashSet<>();

    public OpenAuctions() {
        // Schedule a task to check and remove expired auctions every 20 seconds
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::removeExpiredAuctions, 0, 20, TimeUnit.SECONDS);
    }

    protected List<Enchere> getAuctionsWhereNoBidFromClient(String clientID) {
        List<Enchere> results = new ArrayList<>();
        for(Enchere enchere : auctions) {
            for(Offre offre : Server.getData().getCurrentClientOffers()) {
                if (!enchere.getProduit().equals(offre.getProduct()) && offre.getClient().getId().equals(clientID)) {
                    results.add(enchere);
                }
            }
        }
        return results;
    }

    protected void addAuction(Enchere auction) {
        auctions.add(auction);
    }
    protected void removeAuction(Produit product) {
        for(Enchere openAuction : auctions) {
            if (openAuction.getProduit().equals(product)) {
                auctions.remove(openAuction);
                break;
            }
        }
    }
    private void removeExpiredAuctions() {
        for (Enchere auction : auctions) {
            if (auction.estFini()) {
                Handler adminHandler = ConnectedCheck.adminConnected(Server.getHandlers());
                if (adminHandler == null) {
                    throw new RuntimeException("L'admin a été déconnecté");
                } else {
                    adminHandler.sendDataToClient(new AuctionEnded(auction.getProduit()));
                    auctions.remove(auction);
                }
            }
        }

    }
}
