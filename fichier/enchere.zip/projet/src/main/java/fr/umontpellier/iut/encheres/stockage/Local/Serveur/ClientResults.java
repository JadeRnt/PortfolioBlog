package fr.umontpellier.iut.encheres.stockage.Local.Serveur;

import fr.umontpellier.iut.encheres.reseau.data.Message;


import java.util.*;

public class ClientResults {
    private final Map<Message, String> messages = new HashMap<>();

    public List<Message> getMessagesForClient(String clientID) {
        List<Message> results = new ArrayList<>();
        for (Map.Entry<Message, String> messageStringEntry : messages.entrySet()) {
            if (messageStringEntry.getValue().equals(clientID)) {
                results.add(messageStringEntry.getKey());
            }
        }
        return results;
    }

    public void addMessage(Message message, String clientID) {
        messages.put(message, clientID);
    }
}
