package fr.umontpellier.iut.encheres.utils;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.IOException;

public class JSSE {
    /**
     * Paramètre le keystore
     * @param keyStorePath Chemin vers le keystore
     * @param keyStorePassword Mot de passe du keystore
     */
    public static void configurationKeyStore(String keyStorePath, String keyStorePassword) {
        System.setProperty("javax.net.ssl.keyStore", keyStorePath);
        System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);
    }

    /**
     * Paramètre le truststore
     * @param trustStorePath Chemin vers le truststore
     * @param trustStorePassword Mot de passe du truststore
     */
    public static void configurationTrustStore(String trustStorePath, String trustStorePassword) {
        System.setProperty("javax.net.ssl.trustStore", trustStorePath);
        System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);
    }

    public static void debug() {
        System.setProperty("javax.net.debug", "ssl");
    }
}
