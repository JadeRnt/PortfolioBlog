package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.seller;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserController;
import fr.umontpellier.iut.encheres.ihm.listeners.AuctionEndedListener;
import fr.umontpellier.iut.encheres.ihm.listeners.ClientOfferTransmittedListener;
import fr.umontpellier.iut.encheres.ihm.listeners.WinningOfferTransmitedListener;
import fr.umontpellier.iut.encheres.ihm.scenes.MainScene;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.*;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;


import java.util.*;

public class GetOffersController extends NotifyUserController {

    private Produit productConcerned;

    @FXML
    private Text title;

    @FXML
    private VBox root;

    @FXML
    private Text description;

    @FXML
    private VBox offersContainer;
    @FXML
    private Button deleteProduct;

    private Button actionBtn;

    private Session session;
    private Offre winningOffer;
    private List<Offre> offers;
    private Integer priceToPay;


    @Override
    public void setParameters(Map<String, Object> parameters) {
        productConcerned = (Produit) parameters.get("product");
        title.setText(productConcerned.getTitle());
        description.setText(productConcerned.getDescription());
        session = (Session) parameters.get("session");
        offers = new ArrayList<>();

    }

    public void getOffers() {
        List<PriceWithDate> prices = new ArrayList<>();

        if (offers.isEmpty()) {
            setAlertMessage("Il n'y a pas d'offres sur ce produit");
            deleteProduct.setVisible(true);
            actionBtn.setVisible(false);
        }

        else {
            for (Offre offer : offers) {
                Label clientLabel = new Label();
                clientLabel.setText(offer.getClient().getId());
                offersContainer.getChildren().add(new Text("- Client " + clientLabel.getText()));
                prices.add(new PriceWithDate(offer.getMontant(), offer.getTime()));

            }

            actionBtn.setText("Transmettre les offres");
            actionBtn.setOnAction(event -> transmitOffers(prices));
        }


    }


    private void transmitOffers(List<PriceWithDate> prices) {
        Collections.shuffle(prices);
        Prices data = new Prices(prices, productConcerned);
        session.getSocket().sendData(data);
    }


    public void getWinner() {
        actionBtn.setText("Transmettre l'offre gagnant");
        offersContainer.getChildren().removeIf(label -> {
            String accessibleText = label.getAccessibleText();
            return accessibleText != null && !accessibleText.contains(winningOffer.getClient().getId());
        });
        actionBtn.setOnAction(event -> sendResults());
    }

    private void sendResults() {
        actionBtn.setVisible(false);
        List<Client> losingClients = new ArrayList<>();
        for (Offre offer : offers) {
            if (!offer.getClient().equals(winningOffer.getClient())) {
                losingClients.add(offer.getClient());
            }
        }
        session.getSocket().sendData(new Results(winningOffer.getClient(), losingClients, productConcerned, priceToPay));
    }

    public void setGetOffersBtn() {
        Platform.runLater(() -> {
            String text = "Récupérer les offres";
            if (actionBtn != null) {
                actionBtn.setText(text);
            } else {
                actionBtn = new Button(text);
            }
            actionBtn.setVisible(true);
            actionBtn.setOnAction(event -> getOffers());
            if (!root.getChildren().contains(actionBtn)) {
                root.getChildren().add(actionBtn);
            }
        });
    }

    public Session getSession() {
        return session;
    }




    public void onAuctionEnded(Produit product) {
        ((GetOffersController) Scenes.getScene(product.getIdProduit()).getController()).setGetOffersBtn();
    }

    public void onOffersTransmitted(Prices prices) {
        if (prices.isPricesSent()) {
            setAlertMessage("Les offres ont été transmises");
            actionBtn.setVisible(false);
        }
        else {
            setAlertMessage("Les offres n'ont pas été transmises");
        }
    }


    public void onWinningOfferTransmitted(WinningPrice data) {
        offersContainer.getChildren().removeAll();
        priceToPay = data.getPriceToPay();

        Offre offerTransmitted = new Offre(new Client(), data.getProductConcerned(), data.getEncryptedPrice());

        for (Offre offer : offers) {
            if (offer.equals(offerTransmitted)) {
                winningOffer = offer;
                break;
            }
        }
        if (winningOffer == null) {
            throw new RuntimeException("Winning offer not found");
        }

        actionBtn.setText("Récupérer l'offre gagnant");
        actionBtn.setVisible(true);
        actionBtn.setOnAction(actionEvent -> getWinner());
    }

    public void onClientOfferTransmitted(ClientOffer offer) {
        offers.add(offer.getOffer());
    }

    @FXML
    public void deleteProduct() {
        MainScene.getMain().setCenter(Scenes.getScene("list").getCenterView());
        ListProductControllerVendeur controller = (ListProductControllerVendeur)Scenes.getScene("list").getController();
        controller.removeFromGrid(productConcerned.getIdProduit());
        controller.setAlertMessage("Le produit a été supprimé!");
        session.getSocket().sendData(new ReturnProduct(productConcerned));
        Scenes.removeScene(productConcerned.getIdProduit());
    }
}
