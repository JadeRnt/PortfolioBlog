package fr.umontpellier.iut.encheres.stockage.Local.Client;

import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.reseau.data.Data;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import org.bouncycastle.util.test.FixedSecureRandom;

import java.util.ArrayList;
import java.util.List;

public class ClientInfo implements Data {
    private final List<Offre> offersMade = new ArrayList<>();
    private final List<Message> results = new ArrayList<>();

    public void setResults(List<Message> results) {
        this.results.addAll(results);
    }

    public List<Offre> getOffersMade() {
        return offersMade;
    }

    public void addOffer(Offre offer) {
        offersMade.add(offer);
    }

    public void setOffersMade(List<Offre> offers) {
        offersMade.addAll(offers);
    }

    public List<Message> getResults() {
        return results;
    }
}
