package fr.umontpellier.iut.encheres.ihm.controllers.views.users;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.ConfigureMainController;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.metier.Produit;

import java.util.Map;

public class SellerViewController extends ConfigureMainController {

    public void loadSellerView(Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        loadMainView("/views/seller/productViewSeller.fxml", parameters);
    }

    public void loadGetOffersView(Produit product, Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        parameters.put("product", product);
        Scenes.uploadCenterView(product.getIdProduit(), "/views/seller/getOffersView.fxml", parameters);
    }

    public void loadCreateProductView(Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        Scenes.uploadCenterView("create", "/views/seller/createProductView.fxml", parameters);
    }

}
