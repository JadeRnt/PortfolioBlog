package fr.umontpellier.iut.encheres.ihm.scenes;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.ParametrableController;
import javafx.scene.Scene;

public class SceneInfo {

    private final Scene scene;

    private final ParametrableController controller;

    public SceneInfo(Scene scene, ParametrableController controller) {
        this.scene = scene;
        this.controller = controller;
    }

    public Scene getScene() {
        return scene;
    }

    public ParametrableController getController() {
        return controller;
    }
}
