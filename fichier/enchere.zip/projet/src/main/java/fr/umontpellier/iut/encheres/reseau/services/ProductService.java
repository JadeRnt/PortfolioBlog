package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.data.CreateProduct;
import fr.umontpellier.iut.encheres.reseau.data.ReturnProduct;

import java.util.Map;

public class ProductService {

    protected Map<String, Handler> handlers;

    public ProductService(Map<String, Handler> handlers) {
        this.handlers = handlers;
    }

    public void checkProductValid(Handler handler, CreateProduct product) {
        Handler adminHandler = ConnectedCheck.adminConnected(handlers);
        if (adminHandler != null) {
            adminHandler.sendDataToClient(product);
            product.setProductCreated(true);
        }

        handler.sendDataToClient(product);
    }

    public void requestDeleteAuctionProduct(ReturnProduct returnProduct) {
        Handler adminHandler = ConnectedCheck.adminConnected(handlers);
        if (adminHandler != null) {
            adminHandler.sendDataToClient(returnProduct);
        }
    }
}
