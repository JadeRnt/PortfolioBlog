package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.reseau.Handler;

import java.util.Map;

public abstract class ConnectedCheck {

    protected static Handler userConnected(Map<String, Handler> handlers, Utilisateur user) {
        for (Handler handler : handlers.values()) {
            if (handler.getUser().equals(user)) {
                return handler;
            }
        }
        return null;
    }

    public static Handler adminConnected(Map<String, Handler> handlers) {
        for (Handler handler : handlers.values()) {
            if (handler.getUser().estAdmin()) {
                return handler;
            }
        }
        return null;
    }
}
