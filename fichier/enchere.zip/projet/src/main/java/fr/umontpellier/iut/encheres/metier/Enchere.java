package fr.umontpellier.iut.encheres.metier;

import java.time.Duration;
import java.time.LocalDateTime;

public class Enchere extends AbstractDataObject{

    private final LocalDateTime endTime;

    private final Produit produit;

    /**
     * Construit une enchère.
     * @param produit produit concerné
     * prérequis :
     * - la date de début de l'enchère doit se situer avant la date de fin
     * - le produit doit exister
     * - l'enchère ne doit pas avoir de prix max, en théorie
     * - une enchère ne peut pas concerner plusieurs produits
     */
    public Enchere(Produit produit, Duration duration) {
        this.produit = produit;
        LocalDateTime startTime = LocalDateTime.now();
        endTime = startTime.plus(duration);
    }

    public boolean estFini() {
        return LocalDateTime.now().isAfter(endTime);
    }


    public Produit getProduit() {
        return produit;
    }
}
