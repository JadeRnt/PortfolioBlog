package fr.umontpellier.iut.encheres.utils;

import fr.umontpellier.iut.encheres.metier.Cle;
import fr.umontpellier.iut.encheres.stockage.Repository.AbstractRepository;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import org.bouncycastle.util.io.pem.PemWriter;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Random;

public class KeyUtils {

    public static String publicKeyToPEM(PublicKey publicKey) throws IOException {
        PemObject pemObject = new PemObject("PUBLIC KEY", publicKey.getEncoded());
        return objectToPEM(pemObject);
    }

    public static String privateKeyToPEM(PrivateKey privateKey) throws IOException {
        PemObject pemObject = new PemObject("PRIVATE KEY", privateKey.getEncoded());
        return objectToPEM(pemObject);
    }

    private static String objectToPEM(PemObject pemObject) throws IOException {
        StringWriter stringWriter = new StringWriter();
        try (PemWriter pemWriter = new PemWriter(stringWriter)) {
            pemWriter.writeObject(pemObject);
        }
        return stringWriter.toString();
    }

    public static PublicKey pemToPublicKey(String pem) throws Exception {
        byte[] decoded = pemToObject(pem).getContent();
        X509EncodedKeySpec spec = new X509EncodedKeySpec(decoded);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePublic(spec);
    }

    public static PrivateKey pemToPrivateKey(String pem) throws Exception {
        byte[] decoded = pemToObject(pem).getContent();
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(decoded);
        KeyFactory keyFactory = KeyFactory.getInstance("RSA");
        return keyFactory.generatePrivate(spec);
    }

    private static PemObject pemToObject(String pem) throws IOException {
        try (PemReader pemReader = new PemReader(new StringReader(pem))) {
            return pemReader.readPemObject();
        }
    }

    public static KeyPair generationPaireClef(int taille) throws NoSuchAlgorithmException {
        KeyPairGenerator keyPairGen = KeyPairGenerator.getInstance("RSA");
        keyPairGen.initialize(taille);
        return keyPairGen.generateKeyPair();
    }

    public static String generateRandomString() {
        int length = 255;
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        Random random = new Random();
        StringBuilder sb = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(characters.length());
            sb.append(characters.charAt(index));
        }

        return sb.toString();
    }

    public static SignaturePair generateSignatures() {
        AbstractRepository<Cle> cleRepository = new AbstractRepository<>(Cle.class);
        try{
            Cle privateKey = cleRepository.recupererParClePrimaire("clePrivee");
            Cle publicKey = cleRepository.recupererParClePrimaire("clePublique");


            if (privateKey == null || publicKey == null) {

                KeyPair pair = KeyUtils.generationPaireClef(2048);
                PrivateKey clePrivee = pair.getPrivate();
                PublicKey clePublique = pair.getPublic();


                if (privateKey == null) {
                    cleRepository.sauvegarder(new Cle("clePrivee", KeyUtils.privateKeyToPEM(clePrivee)));
                }
                else {
                    cleRepository.mettreAJour(new Cle("clePrivee", KeyUtils.privateKeyToPEM(clePrivee)));
                }

                if (publicKey==null) {
                    cleRepository.sauvegarder(new Cle("clePublique", KeyUtils.publicKeyToPEM(clePublique)));
                }
                else {
                    cleRepository.mettreAJour(new Cle("clePublique", KeyUtils.publicKeyToPEM(clePublique)));
                }
                return new SignaturePair(clePrivee, clePublique);
            }
            return new SignaturePair(KeyUtils.pemToPrivateKey(privateKey.getCle().trim()), KeyUtils.pemToPublicKey(publicKey.getCle().trim()));

        }
        catch(Exception e) {
            System.out.println("Erreur lors de la génération des clés");
        }
        return null;
    }
}
