package fr.umontpellier.iut.encheres.ihm.controllers.views.users;

import fr.umontpellier.iut.encheres.ihm.setupStrategy.ClientAuctionProductSetupStrategy;
import fr.umontpellier.iut.encheres.ihm.setupStrategy.ClientOfferProductSetupStrategy;
import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.ConfigureMainController;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;

import java.util.Map;

public class ClientViewController extends ConfigureMainController {

    public void loadClientView(Session session, Service service, ClientHandlerInfo handlerInfo) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        parameters.put("handlerInfo", handlerInfo);
        parameters.put("setupStrategy", new ClientAuctionProductSetupStrategy());
        loadMainView("/views/client/productViewClient.fxml", parameters);
    }

    public void loadCreateOfferView(Produit product, Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        parameters.put("product", product);
        Scenes.uploadCenterView(product.getIdProduit(),"/views/client/createOfferView.fxml", parameters);
    }

    public void loadOffersMadeView(Session session, Service service) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        parameters.put("setupStrategy", new ClientOfferProductSetupStrategy());
        Scenes.uploadCenterView("offers","/views/client/offersMadeView.fxml", parameters);
    }

    public void loadResultsView(Session session, Service service, Offre offer, Message message) {
        Map<String, Object> parameters = setBasicParameters(session, service);
        parameters.put("offer", offer);
        parameters.put("message", message);
        Scenes.uploadCenterView(offer.getProduct().getIdProduit(), "/views/client/auctionResultView.fxml", parameters);
    }


}
