package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;


public class Login implements DataAction {

    private String mdp;
    private Utilisateur connectedUser;

    private String username;

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.handleLogin(this, handler);
    }


    public Login(String mdp, String username) {
        this.mdp = mdp;
        this.username = username;
    }

    public String getMdp() {
        return mdp;
    }


    public String getUsername() {
        return username;
    }

    public Utilisateur getConnectedUser() {
        return connectedUser;
    }

    public void setConnectedUser(Utilisateur connectedUser) {
        this.connectedUser = connectedUser;
    }
}
