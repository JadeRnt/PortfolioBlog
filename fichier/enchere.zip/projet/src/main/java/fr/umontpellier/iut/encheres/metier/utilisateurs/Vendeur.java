package fr.umontpellier.iut.encheres.metier.utilisateurs;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.SellerViewController;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import fr.umontpellier.iut.encheres.stockage.Repository.AbstractRepository;
import jakarta.persistence.Entity;
import jakarta.persistence.Transient;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@Entity
public class Vendeur extends Utilisateur {

    /**
     * Construit un utilisateur
     * @param dateNaissance prérequis : l'utilisateur est majeur
     */
    public Vendeur(String id, LocalDate dateNaissance,String mdp, String signature) {
        super(id, dateNaissance,mdp,signature);
        setRole("V");
    }

    public Vendeur(String id) {
        super(id);
        setRole("V");
    }

    public Vendeur() {

    }


    @Override
    public void loadProductView(Produit product, Session session, Service service) {
        new SellerViewController().loadGetOffersView(product, session, service);
    }

    @Override
    public void loadUserView(Session session, Service service, ClientHandlerInfo handlerInfo) {
        new SellerViewController().loadSellerView(session, service);
    }

    @Override
    public void saveUser() {
        new AbstractRepository<>(Vendeur.class).sauvegarder(this);
    }

    @Transient
    public Map<String, String> getTabOptions(Session session, Service service) {
        Map<String, String> tabs = new HashMap<>();
        tabs.put("Nouveau produit", "create");
        tabs.put("Produits Vendus", "list");
        new SellerViewController().loadCreateProductView(session, service);
        return tabs;
    }

}

