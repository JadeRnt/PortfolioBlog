package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

import java.util.List;

public class Results implements DataAction {

    private final Client winningUser;
    private final Produit productConcerned;
    private final Integer priceToPay;

    private final List<Client> listLosingBidders;

    public Results(Client winner, List<Client> losers, Produit product, Integer priceToPay) {
        winningUser = winner;
        listLosingBidders = losers;
        productConcerned = product;
        this.priceToPay = priceToPay;
    }

    public Client getWinningUser() {
        return winningUser;
    }

    public List<Client> getListLosingBidders() {
        return listLosingBidders;
    }

    public Integer getPriceToPay() {
        return priceToPay;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.sendAuctionResults(this);
    }

    public Produit getProductConcerned() {
        return productConcerned;
    }
}
