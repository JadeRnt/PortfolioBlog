package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.admin;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserListProductController;
import fr.umontpellier.iut.encheres.ihm.listeners.*;
import fr.umontpellier.iut.encheres.ihm.scenes.MainScene;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.*;
import javafx.application.Platform;

import java.util.*;

public class ListProductControllerAdmin extends NotifyUserListProductController
        implements ProductCreatedListener, OffersTransmittedListener,
        WinningOfferTransmitedListener, AuctionEndedListener,
        AuctionStartedListener, ReturnProductListener
{

    @Override
    public void setParameters(Map<String, Object> parameters) {
        super.setParameters(parameters);
        setUpService(this);
    }

    @Override
    public void onProductCreated(CreateProduct productCreated) {
        setAlertMessage("Un nouveau produit a été crée! Cliquez dessus pour pouvoir démarrer une enchère");
        updateProductGrid(productCreated.getProduct());
    }

    @Override
    public void onOffersTransmitted(Prices prices) {
        AuctionController controller = (AuctionController) Scenes.getScene(prices.getProduct().getIdProduit()).getController();
        controller.onOffersTransmitted(prices);
    }

    @Override
    public void onWinningOfferTransmitted(WinningPrice data) {
        ((AuctionController) Scenes.getScene(data.getProductID()).getController()).onWinningOfferTransmitted(data);
    }

    @Override
    public void onAuctionEnded(Produit produit) {
        ((AuctionController) Scenes.getScene(produit.getIdProduit()).getController()).auctionEnded();
    }

    @Override
    public void onAuctionStarted(AuctionStarted dataReceived) {
        ((AuctionController) Scenes.getScene(dataReceived.getAuction().getProduit().getIdProduit()).getController()).confirmAuctionStarted(dataReceived);
    }

    @Override
    public void onProductReturned(ReturnProduct returnProduct) {
        Platform.runLater(()-> {
            removeFromGrid(returnProduct.getProductConcerned().getIdProduit());
            MainScene.getMain().setCenter(Scenes.getScene("list").getCenterView());
            Scenes.removeScene(returnProduct.getProductConcerned().getIdProduit());
        });

    }
}
