package fr.umontpellier.iut.encheres.ihm.controllers;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.UserViewController;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.SocketInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.SignUp;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Vendeur;

import fr.umontpellier.iut.encheres.utils.KeyUtils;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

import java.io.File;
import java.io.IOException;


public class SignUpController {
    @FXML
    private RadioButton choiceClient;

    @FXML
    private RadioButton choiceSeller;

    @FXML
    private HBox errorMessage;

    @FXML
    private PasswordField mdp;

    @FXML
    private TextField login;

    @FXML
    private Text errorMessageText;

    @FXML
    private DatePicker birthdate;

    @FXML
    public void handleSignUp() {

        if (mdp.getText().isEmpty() || login.getText().isEmpty() || (!choiceSeller.isSelected() && !choiceClient.isSelected())) {
            errorMessageText.setText("Veuillez remplir tous les champs.");
            errorMessage.setVisible(true);
        }
        else {
            Utilisateur newUser;
            String mdpHashe = BCrypt.hashpw(mdp.getText(), BCrypt.gensalt(12));
            if (choiceClient.isSelected()) {
                newUser = new Client(login.getText(), birthdate.getValue(), mdpHashe, KeyUtils.generateRandomString());
            }
            else {
                newUser = new Vendeur(login.getText(), birthdate.getValue(), mdpHashe, KeyUtils.generateRandomString());
            }

            SocketInfo socket = new SocketInfo();
            SignUp signUp = new SignUp(newUser);
            socket.sendData(signUp);

            Object data = socket.receiveData();
            if (data instanceof ClientHandlerInfo) {
                if (((ClientHandlerInfo) data).getConnectedUser()!=null) {
                    Session session = new Session(((ClientHandlerInfo) data).getConnectedUser(), socket, ((ClientHandlerInfo) data).getClientID());
                    session.getConnectedUser().loadUserView(session, new Service(), (ClientHandlerInfo) data);
                }
                else {
                    errorMessageText.setText("Ce login d'utilisateur existe déjà");
                    errorMessage.setVisible(true);
                }
            }

        }

    }

    @FXML
    public void loadLoginView() {
        (new UserViewController()).loadLoginView();
    }

    @FXML
    public void showPopup() {
        try {
            File pdfFile = new File("src/resources/CGU.pdf");

            // Use ProcessBuilder to open the default PDF viewer with the local PDF file
            String os = System.getProperty("os.name").toLowerCase();

            ProcessBuilder processBuilder;
            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "start", "\"\"", pdfFile.getAbsolutePath());
            } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
                processBuilder = new ProcessBuilder("xdg-open", pdfFile.getAbsolutePath());
            } else {
                throw new UnsupportedOperationException("Unsupported operating system");
            }

            processBuilder.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}
