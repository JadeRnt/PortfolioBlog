package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.WinningPrice;

public interface WinningOfferTransmitedListener extends Listener{

    void onWinningOfferTransmitted(WinningPrice data);
}
