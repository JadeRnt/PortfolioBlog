package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.Message;


public interface ResultListener extends Listener {
    void onResultReceived(Message message);
}

