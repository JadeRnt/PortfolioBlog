//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.utils;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.repositories.EntityRepositoryDatabase;
import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.api.EntityRepository;
import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class RepositoryManager {
    private static Map<Class, EntityRepository> customrepositories = new HashMap();
    private static final String CONFIG = "customRepositories.cfg.xml";

    public RepositoryManager() {
    }

    private static void loadCustomRepositories() {
        try {
            InputStream stream = ClassLoader.getSystemResourceAsStream("customRepositories.cfg.xml");
            if (stream != null) {
                DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
                dbf.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
                DocumentBuilder db = dbf.newDocumentBuilder();
                if (db != null) {
                    Document doc = db.parse(stream);
                    doc.getDocumentElement().normalize();
                    NodeList list = doc.getDocumentElement().getElementsByTagName("repository");

                    for(int i = 0; i < list.getLength(); ++i) {
                        Node customRepo = list.item(i);
                        NamedNodeMap attr = customRepo.getAttributes();
                        String repoClassText = attr.getNamedItem("class").getTextContent();
                        Class<?> repoClass = Class.forName(repoClassText);
                        if (EntityRepository.class.isAssignableFrom(repoClass)) {
                            Constructor<?> constructor = repoClass.getConstructor();
                            EntityRepository<?> repository = (EntityRepository)constructor.newInstance();
                            customrepositories.put(repository.getType(), repository);
                        }
                    }
                }
            }
        } catch (IOException | SAXException | ClassNotFoundException | NoSuchMethodException | InstantiationException | InvocationTargetException | IllegalAccessException | ParserConfigurationException var12) {
            var12.printStackTrace();
        }

    }

    public static <T> EntityRepository<T> getRepository(Class<T> type) {
        if (!customrepositories.containsKey(type)) {
            customrepositories.put(type, new EntityRepositoryDatabase<T>(type) {
            });
        }

        return (EntityRepository)customrepositories.get(type);
    }

    static {
        loadCustomRepositories();
    }
}
