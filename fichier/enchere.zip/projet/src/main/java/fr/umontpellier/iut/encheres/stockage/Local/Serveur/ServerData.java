package fr.umontpellier.iut.encheres.stockage.Local.Serveur;

import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.Message;

import java.util.List;
import java.util.Set;

public class ServerData {

    protected final Offers currentClientOffers = new Offers();

    private final OpenAuctions openAuctions = new OpenAuctions();
    private final ClientResults clientResults = new ClientResults();
    
    public List<Offre> getOffersMadeByClient(String clientID) {
        return  currentClientOffers.getOffersMadeByClient(clientID);
    }

    public void addAuction(Enchere auction) {
        openAuctions.addAuction(auction);
    }
    public void removeAuction(Produit productConcerned) { openAuctions.removeAuction(productConcerned);}

    public List<Enchere> getAuctionsWhereNoBidFromClient(String clientID) {

        return openAuctions.getAuctionsWhereNoBidFromClient(clientID);
    }

    public void addOffer(Offre offer) {
        currentClientOffers.addOffer(offer);
    }

    public Set<Offre> getCurrentClientOffers() {
        return currentClientOffers.getCurrentClientOffers();
    }

    public ClientResults getClientResults() {
        return clientResults;
    }
}
