package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import fr.umontpellier.iut.encheres.reseau.data.Results;

import java.util.Map;

public class ResultService {

    protected Map<String, Handler> handlers;
    public ResultService(Map<String, Handler> handlers) {
        this.handlers = handlers;
    }

    public void sendResults(Results results) {
        Handler winningClient = ConnectedCheck.userConnected(handlers, results.getWinningUser());
        Message winningMessage = new Message("Bravo, vous avez gagné l'enchère avec un prix final à payer de "+results.getPriceToPay()+"€", results.getProductConcerned());
        if (winningClient != null) {
            winningClient.sendDataToClient(winningMessage);
        }
        Server.getData().getClientResults().addMessage(winningMessage, results.getWinningUser().getId());

        for (Client losingClient : results.getListLosingBidders()) {
            Handler loser = ConnectedCheck.userConnected(handlers, losingClient);
            Message losingMessage = new Message("Dommage, vous n'avez pas gagné", results.getProductConcerned());
            if (loser != null) {
                loser.sendDataToClient(losingMessage);
            }
            Server.getData().getClientResults().addMessage(losingMessage, losingClient.getId());
        }
    }
}
