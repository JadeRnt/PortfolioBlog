package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;

public class SignUp implements DataAction {

    private final Utilisateur user;
    private boolean signUpSuccess;


    public SignUp(Utilisateur user) {
        this.user = user;
    }

    public void setSignUpSuccess(boolean signUpSuccess) {
        this.signUpSuccess = signUpSuccess;
    }

    public boolean isSignUpSuccess() {
        return signUpSuccess;
    }

    public Utilisateur getUser() {
        return user;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.handleSignIn(handler, this);
    }

}
