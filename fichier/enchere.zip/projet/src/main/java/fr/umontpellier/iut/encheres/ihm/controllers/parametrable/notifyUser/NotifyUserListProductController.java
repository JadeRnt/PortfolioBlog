package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser;
import fr.umontpellier.iut.encheres.ihm.scenes.*;
import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.Listener;
import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.metier.Produit;

import javafx.application.Platform;
import javafx.fxml.FXML;
import fr.umontpellier.iut.encheres.reseau.Session;

import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

import java.util.List;
import java.util.Map;


public class NotifyUserListProductController extends NotifyUserController {

    @FXML
    protected GridPane productGrid;

    private Session session;
    protected Service<Listener> service;

    protected Label getLabel(Object object) {
        if (object instanceof Produit) {
            Produit product = (Produit) object;
            Label label = new Label(product.getTitle());
            label.setId(product.getIdProduit());
            //Add scenes to the list of scenes
            CenterView productScene = Scenes.getScene(product.getIdProduit());

            if (productScene == null) {
                session.getConnectedUser().loadProductView(product, session, service);
                productScene = Scenes.getScene(product.getIdProduit());
            }
            action(label, productScene);
            return label;
        }
        else {
            Enchere product = (Enchere) object;
            Label label = new Label(product.getProduit().getTitle());
            label.setId(product.getProduit().getIdProduit());
            //Add scenes to the list of scenes
            CenterView productScene = Scenes.getScene(product.getProduit().getIdProduit());

            if (productScene == null) {
                session.getConnectedUser().loadProductView(product.getProduit(), session, service);
                productScene = Scenes.getScene(product.getProduit().getIdProduit());
            }
            action(label, productScene);
            return label;
        }
    }

    public void action(Label label, CenterView productScene) {
        label.setOnMouseClicked(event -> {
            MainScene.getMain().setCenter(productScene.getCenterView());
        });
    }

    public Session getSession() {
        return session;
    }

    @Override
    public void setParameters(Map<String, Object> parameters) {
        session = (Session) parameters.get("session");
        service = (Service<Listener>) parameters.get("service");
    }

    protected void setUpService(Listener listener) {
        service.setController(listener);
        if (!service.isStarted()) {
            service.setPeriod(Duration.seconds(5));
            service.start();
            service.setStarted();
        }
    }

    public void updateProductGrid(Object object) {
        Platform.runLater(() -> {
            int nbCurrentProducts = productGrid.getChildren().size();

            int lastRowIndex = nbCurrentProducts / 3;
            int columnNumber = nbCurrentProducts % 3;

            Label newLabel = getLabel(object);
            productGrid.getChildren().add(newLabel);

            // Set the column and row index explicitly
            GridPane.setColumnIndex(newLabel, columnNumber);
            GridPane.setRowIndex(newLabel, lastRowIndex);
        });
    }

    public void setupProductGrid(List<?> objects) {
        Platform.runLater(() -> {
            int numCols = 3;

            for (int i = 0; i < objects.size(); i++) {
                Object object = objects.get(i);

                int row = i / numCols;
                int col = i % numCols;

                Label label = getLabel(object);

                productGrid.add(label, col, row);

            }
        });
    }

    public void removeFromGrid(String productID) {
        for(Node child : productGrid.getChildren()) {
            if (child.getId().equals(productID)) {
                productGrid.getChildren().remove(child);
                break;
            }
        }

    }



}
