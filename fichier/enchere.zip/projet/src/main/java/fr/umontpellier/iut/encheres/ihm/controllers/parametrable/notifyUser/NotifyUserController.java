package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.ParametrableController;
import fr.umontpellier.iut.encheres.ihm.listeners.Listener;
import fr.umontpellier.iut.encheres.reseau.data.DataWithReturnAction;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.util.Duration;

public abstract class NotifyUserController implements ParametrableController, Listener {
    @FXML
    private HBox alertMessage;
    @FXML
    private Text alertText;
    int secondsToShow = 5;

    // Create a Timeline with a KeyFrame to hide the HBox after the specified duration
    Timeline timeline = new Timeline(new KeyFrame(
            Duration.seconds(secondsToShow),
            event -> alertMessage.setVisible(false)
    ));

    @Override
    public void notifyUser(Service<?> service) {
        Object data = getSession().getSocket().receiveData();
        ((DataWithReturnAction)data).executeReturnAction(service);
    }

    public void setAlertMessage(String message) {
        alertText.setText(message);
        alertMessage.setVisible(true);
        timeline.playFromStart();
    }



}
