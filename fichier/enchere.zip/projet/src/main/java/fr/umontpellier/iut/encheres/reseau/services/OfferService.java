package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.data.ClientOffer;
import fr.umontpellier.iut.encheres.reseau.data.PriceWithDate;
import fr.umontpellier.iut.encheres.reseau.data.Prices;
import fr.umontpellier.iut.encheres.reseau.data.WinningPrice;

import java.util.Map;

public class OfferService {

    protected Map<String, Handler> handlers;

    public OfferService(Map<String, Handler> handlers) {
        this.handlers = handlers;
    }

    public void transmitOffers(Handler handler, Prices prices) {
        Handler adminHandler = ConnectedCheck.adminConnected(handlers);
        if (adminHandler!=null){
            prices.setPricesSent(true);
            adminHandler.sendDataToClient(prices);
        }
        handler.sendDataToClient(prices);
    }

    public void sendOfferToSeller(Handler handler, ClientOffer offer) {
        Handler sellerHandler = ConnectedCheck.userConnected(handlers, offer.getSeller());

        if (sellerHandler != null) {
            sellerHandler.sendDataToClient(offer);
            Server.getData().addOffer(offer.getOffer());
        }
        //handler.sendDataToClient(offer);
    }

    public void transmitWinningOffer(WinningPrice winningPrice, Handler handlerAdmin) {
        Utilisateur ownerProduct = winningPrice.getProductConcerned().getSeller();
        Handler handler = ConnectedCheck.userConnected(handlers, ownerProduct);
        if (handler != null) {
            winningPrice.setTransmissionSuccess(true);
            handler.sendDataToClient(winningPrice);
        }

        handlerAdmin.sendDataToClient(winningPrice);
    }
}
