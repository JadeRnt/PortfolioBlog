package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.AuctionEndedListener;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import fr.umontpellier.iut.encheres.metier.Produit;

public class AuctionEnded implements DataWithReturnAction, DataAction {

    private final Produit product;

    public AuctionEnded(Produit product) {
        this.product = product;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.transmitAuctionEndedSignal(this);
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        ((AuctionEndedListener)service.getController()).onAuctionEnded(product);
    }

    public Produit getProduct() {
        return product;
    }
}
