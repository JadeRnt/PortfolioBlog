package fr.umontpellier.iut.encheres.ihm.controllers.parametrable;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.UserViewController;
import fr.umontpellier.iut.encheres.reseau.Session;
import javafx.fxml.FXML;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.VBox;

import java.util.Map;

public class MenuController implements ParametrableController {
    @FXML
    private VBox navBar;
    private Session session;
    private Service service;

    public void loadTabs() {
        createTabs(session.getConnectedUser().getTabOptions(session, service));
    }


    private void createTabs(Map<String, String> tabs) {
        for(Map.Entry<String, String> tab : tabs.entrySet()) {
            Hyperlink newTab = new Hyperlink();
            newTab.setText(tab.getKey());
            newTab.setOnAction(event -> (new UserViewController()).loadMenuTabView(tab.getValue()));
            navBar.getChildren().add(newTab);
        }
    }

    @Override
    public void setParameters(Map<String, Object> parameters) {
        session = (Session) parameters.get("session");
        service = (Service) parameters.get("service");
        loadTabs();
    }

    @Override
    public Session getSession() {
        return session;
    }

}
