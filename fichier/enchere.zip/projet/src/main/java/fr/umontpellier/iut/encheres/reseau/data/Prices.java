package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.OffersTransmittedListener;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import fr.umontpellier.iut.encheres.metier.Produit;

import java.util.List;

public class Prices implements DataWithReturnAction, DataAction {
    private final Produit product;
    private final List<PriceWithDate> prices;
    private boolean pricesSent;

    public Prices(List<PriceWithDate> prices, Produit product) {
        this.prices = prices;
        this.product = product;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.transmitOffers(handler, this);
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        ((OffersTransmittedListener)service.getController()).onOffersTransmitted(this);
    }

    public List<PriceWithDate> getPrices() {
        return prices;
    }

    public Produit getProduct() {
        return product;
    }

    public boolean isPricesSent() {
        return pricesSent;
    }

    public void setPricesSent(boolean pricesSent) {
        this.pricesSent = pricesSent;
    }
}
