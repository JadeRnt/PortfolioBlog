package fr.umontpellier.iut.encheres.metier.utilisateurs;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.ClientViewController;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import fr.umontpellier.iut.encheres.reseau.data.Results;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import fr.umontpellier.iut.encheres.stockage.Local.Client.ClientInfo;
import fr.umontpellier.iut.encheres.stockage.Repository.AbstractRepository;
import fr.umontpellier.iut.encheres.utils.KeyUtils;
import jakarta.persistence.Entity;
import jakarta.persistence.Transient;

import javax.crypto.Cipher;
import java.security.PublicKey;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Entity(name = "Client")
public class Client extends Utilisateur{

    @Transient
    private final ClientInfo clientInfo = new ClientInfo();
    /**
     * Construit un utilisateur
     * @param dateNaissance prérequis : l'utilisateur est majeur
     */
    public Client(String id, LocalDate dateNaissance,String mdp,String signature) {
        super(id, dateNaissance, mdp,signature);
        setRole("C");
    }

    public void setResults(List<Message> results) {
        clientInfo.setResults(results);
    }

    @Transient
    public List<Message> getResults() {
        return clientInfo.getResults();
    }



    /**
     * L'utilisateur pose une offre de montant `montant` sur l'enchère e
     * @param product produit sur lequel on veut enchérir
     * @param montant montant
     * prérequis : l'enchère est en cours, montant > 0
     */
    public Offre encherir(Produit product, String montant){
        String montantChiffre = chiffrerMonEnchere(montant);
        if (montantChiffre != null) {
            Offre encherir = new Offre(this, product, montantChiffre, LocalDateTime.now());
            clientInfo.addOffer(encherir);
            return encherir;
        }

        return null;
    }


    private String chiffrerMonEnchere(String enchere) {

        try {
            PublicKey publicKey = KeyUtils.pemToPublicKey(this.publicKey.getCle());
            Cipher chiffreur = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            chiffreur.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] texteChiffre = chiffreur.doFinal(enchere.getBytes());
            return Base64.getEncoder().encodeToString(texteChiffre);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    public void setOffers(List<Offre> offers) {
        clientInfo.setOffersMade(offers);
    }

    @Transient
    public List<Offre> getOffers() {
        return clientInfo.getOffersMade();
    }

    public Client() {
        super();
    }


    @Override
    public void loadUserView(Session session, Service service, ClientHandlerInfo handlerInfo) {
        new ClientViewController().loadClientView(session, service, handlerInfo);
    }



    @Override
    public void saveUser() {
        (new AbstractRepository<>(Client.class)).sauvegarder(this);
    }

    @Override
    public void loadProductView(Produit product, Session session, Service service) {
        new ClientViewController().loadCreateOfferView(product, session, service);
    }

    @Transient
    @Override
    public Map<String, String> getTabOptions(Session session, Service service) {
        Map<String, String> tabs = new HashMap<>();
        tabs.put("Enchères en cours", "list");
        tabs.put("Offres réalisées", "offers");
        new ClientViewController().loadOffersMadeView(session, service);
        return tabs;
    }


    @Override
    public ClientHandlerInfo loadPreviousData(Handler handler) {
        return new ClientHandlerInfo(handler.getClientID(), this, Server.getData().getOffersMadeByClient(this.getId()),
                Server.getData().getAuctionsWhereNoBidFromClient(getId()),
                Server.getData().getClientResults().getMessagesForClient(getId()));
    }

}
