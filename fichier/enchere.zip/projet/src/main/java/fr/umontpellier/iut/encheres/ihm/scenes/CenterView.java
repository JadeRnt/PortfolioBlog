package fr.umontpellier.iut.encheres.ihm.scenes;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.ParametrableController;
import javafx.scene.Node;

public class CenterView {

    private final ParametrableController controller;

    private final Node centerView;



    public CenterView(Node centerView, ParametrableController controller) {
        this.controller = controller;
        this.centerView = centerView;
    }

    public ParametrableController getController() {
        return controller;
    }

    public Node getCenterView() {
        return centerView;
    }
}
