package fr.umontpellier.iut.encheres.ihm.setupStrategy;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserListProductController;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;

public interface ProductGridSetupStrategy {
    void setUpProductGrid(NotifyUserListProductController controller, Client client, ClientHandlerInfo handlerInfo);
}
