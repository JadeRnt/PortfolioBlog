package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.ReturnProductListener;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

public class ReturnProduct implements DataAction, DataWithReturnAction{

    private final Produit productConcerned;

    public ReturnProduct(Produit productConcerned) {
        this.productConcerned = productConcerned;
    }

    public Produit getProductConcerned() {
        return productConcerned;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.requestDeleteAuctionProduct(this);
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        ((ReturnProductListener)service.getController()).onProductReturned(this);
    }
}
