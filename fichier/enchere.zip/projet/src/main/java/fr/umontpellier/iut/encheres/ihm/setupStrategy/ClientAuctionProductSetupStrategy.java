package fr.umontpellier.iut.encheres.ihm.setupStrategy;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserListProductController;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;

public class ClientAuctionProductSetupStrategy implements ProductGridSetupStrategy {
    @Override
    public void setUpProductGrid(NotifyUserListProductController controller, Client client, ClientHandlerInfo handlerInfo) {
        if (client.getOffers().isEmpty()) {
            /* Store all the offers made by client on client side for
            futur reference whilst the app is running
            */
            client.setOffers(((ClientHandlerInfo)handlerInfo).getOffersMade());
            client.setResults(handlerInfo.getClientResults());
            /* Set up the product grid with the open auctions that the client hasn't bid
            on yet
            */
            controller.setupProductGrid(((ClientHandlerInfo)handlerInfo).getOpenAuctions());
        }
    }

}
