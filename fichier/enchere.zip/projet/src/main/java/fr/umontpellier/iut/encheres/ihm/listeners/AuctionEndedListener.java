package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.metier.Produit;

public interface AuctionEndedListener extends Listener {
    void onAuctionEnded(Produit produit);
}
