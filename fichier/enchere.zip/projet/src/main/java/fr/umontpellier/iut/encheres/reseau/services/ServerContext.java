package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.data.*;

import java.util.Map;

public class ServerContext {
    private final UserManagementService userManagementService;
    private final ProductService productService;
    private final AuctionService auctionService;
    private final OfferService offerService;
    private final ResultService resultService;



    public ServerContext(Map<String, Handler> handlers) {
        this.userManagementService = new UserManagementService(handlers);
        this.productService = new ProductService(handlers);
        this.auctionService = new AuctionService(handlers);
        this.offerService = new OfferService(handlers);
        this.resultService = new ResultService(handlers);
        
    }



    public void transmitAuctionEndedSignal(AuctionEnded auctionEnded) {
        auctionService.transmitAuctionEndedSignal(auctionEnded);
    }

    public void transmitAuctionStartedSignal(Handler handler, AuctionStarted auctionStarted) {
        auctionService.transmitAuctionStartedSignal(handler, auctionStarted);
    }

    public void transmitOffers(Handler handler, Prices prices) {
        offerService.transmitOffers(handler, prices);
    }

    public void sendOfferToSeller(Handler handler, ClientOffer offer) {
        offerService.sendOfferToSeller(handler, offer);
    }

    public void transmitWinningOffer(WinningPrice price, Handler handlerAdmin) {
        offerService.transmitWinningOffer(price, handlerAdmin);
    }

    public void checkProductValid(Handler handler, CreateProduct createProduct) {
        productService.checkProductValid(handler, createProduct);
    }

    public void handleLogin(Login login, Handler handler) {
        userManagementService.handleLogin(login, handler);
    }

    public void handleSignIn(Handler handler, SignUp signUp) {
        userManagementService.handleSignIn(handler, signUp);
    }

    public void deconnectUser(Handler handler) {
        userManagementService.deconnectUser(handler);
    }

    public void sendAuctionResults(Results results) { resultService.sendResults(results);}

    public void requestDeleteAuctionProduct(ReturnProduct returnProduct) {
        productService.requestDeleteAuctionProduct(returnProduct);
    }





}
