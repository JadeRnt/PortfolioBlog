package fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.api;

import java.util.List;

public interface EntityRepository<T> {

    List<T> findAll();

    T findByID(Object id);

    void create(T entity);

    void update(T entity);

    void delete(T entity);

    void deleteById(Object id);

    Class<T> getType();

}
