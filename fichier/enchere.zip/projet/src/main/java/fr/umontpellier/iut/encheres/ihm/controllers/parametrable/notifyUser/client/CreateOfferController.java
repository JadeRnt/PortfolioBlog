package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.client;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserController;
import fr.umontpellier.iut.encheres.ihm.scenes.MainScene;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Cle;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.data.ClientOffer;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;

import java.util.Map;

public class CreateOfferController extends NotifyUserController {

    @FXML
    private Text title;

    @FXML
    private Text description;

    @FXML
    private TextField priceInput;

    private Session session;
    private Produit productConcerned;

    public void initialize() {
        priceInput.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*\\.?\\d*")) {
                priceInput.setText(oldValue);
            }
        });


    }

    @Override
    public void setParameters(Map<String, Object> parameters) {
        productConcerned = (Produit) parameters.get("product");
        if (productConcerned == null) {
            throw new RuntimeException("Product not set in parameters ! ");
        }
        title.setText(productConcerned.getTitle());
        description.setText(productConcerned.getDescription());
        session = (Session) parameters.get("session");
    }

    @Override
    public Session getSession() {
        return session;
    }

    @FXML
    public void validateOffer() {
        if (priceInput.getText().isEmpty()) {
            setAlertMessage("Veuillez donner un montant");
        }
        else {
            try {

                Offre offer = ((Client) session.getConnectedUser()).encherir(productConcerned, priceInput.getText());
                session.getSocket().sendData(new ClientOffer(offer));

                // Change view to main page
                ListProductControllerClient controller = ((ListProductControllerClient) Scenes.getScene("list").getController());
                controller.removeFromGrid(productConcerned.getIdProduit());
                controller.setAlertMessage("Votre offre a été envoyé !");
                Scenes.removeScene(productConcerned.getIdProduit());
                ((OfferController) Scenes.getScene("offers").getController()).updateProductGrid(offer);
                MainScene.getMain().setCenter(Scenes.getScene("list").getCenterView());
            }
            catch (Exception e) {
                e.printStackTrace();
            }

        }
    }
}
