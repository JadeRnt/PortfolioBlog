package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.ProductCreatedListener;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import fr.umontpellier.iut.encheres.metier.Produit;

public class CreateProduct implements DataWithReturnAction, DataAction {

    private final Produit product;
    private boolean productCreated = false;

    public CreateProduct(Produit product) {
        this.product = product;
    }



    @Override
    public void executeAction(ServerContext context, Handler handler) {
        Thread thread = new Thread(() ->  context.checkProductValid(handler, this));
        thread.start();
    }

    @Override
    public void executeReturnAction(Service<?> listener) {
        ((ProductCreatedListener) listener.getController()).onProductCreated(this);
    }

    public Produit getProduct() {
        return product;
    }

    public boolean isCreated() {
        return productCreated;
    }

    public void setProductCreated(boolean productCreated) {
        this.productCreated = productCreated;
    }
}
