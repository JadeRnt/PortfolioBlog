package fr.umontpellier.iut.encheres.ihm.controllers.views;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.*;
import fr.umontpellier.iut.encheres.ihm.scenes.*;
import fr.umontpellier.iut.encheres.reseau.Session;
import javafx.fxml.FXMLLoader;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ConfigureMainController {

    public void loadMainView(String viewPath, Map<String, Object> parameters) {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/userView.fxml"));
        try {
            BorderPane center = loader.load();
            // Main scene (aka the list of products) must be loaded first (before menu and header)
            SceneInfo mainScene = MainScene.getMain().loadView("list", viewPath, parameters);
            MainScene.getMain().setMainContainer(center);
            MainScene.getMain().loadMenu(parameters);
            MainScene.getMain().loadHeader(parameters);
            MainController.showView(mainScene.getScene());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected Map<String, Object> setBasicParameters(Session session, Service service) {
        Map<String, Object> parameters = new HashMap<>();
        parameters.put("session", session);
        parameters.put("service", service);
        return parameters;
    }


}
