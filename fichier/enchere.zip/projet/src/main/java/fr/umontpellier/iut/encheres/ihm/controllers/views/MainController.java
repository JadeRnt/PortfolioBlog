package fr.umontpellier.iut.encheres.ihm.controllers.views;

import fr.umontpellier.iut.encheres.ihm.StageManager;
import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.ParametrableController;
import fr.umontpellier.iut.encheres.ihm.scenes.CenterView;
import fr.umontpellier.iut.encheres.ihm.scenes.MainScene;
import fr.umontpellier.iut.encheres.ihm.scenes.SceneInfo;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

public class MainController {

    @FXML
    private BorderPane mainContainer;

    public void initialize() {
        MainScene.setMainController(this);
    }

    public void loadMenu(Map<String, Object> parameters) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/menu.fxml"));
            Node menu = loader.load();
            ParametrableController menuController = loader.getController();
            menuController.setParameters(parameters);
            mainContainer.setLeft(menu);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadHeader(Map<String, Object> parameters) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/header.fxml"));
            Node header = loader.load();
            ParametrableController headerController = loader.getController();
            headerController.setParameters(parameters);
            mainContainer.setTop(header);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public SceneInfo loadView(String viewID, String viewPath, Map<String, Object> parameters) {
        CenterView center = Scenes.uploadCenterView(viewID, viewPath, parameters);
        mainContainer.setCenter(center.getCenterView());

        center.getController().setParameters(parameters);

        Scene mainScene = new Scene(mainContainer);
        mainScene.getStylesheets().add(getClass().getResource("/login.css").toExternalForm());
        return new SceneInfo(mainScene, center.getController());
    }


    public static void showView(Scene scene) {
        Stage currentStage = StageManager.getInstance().getCurrentStage();
        currentStage.setScene(scene);
        currentStage.show();
    }

    public void setCenter(Node centerView) {
        mainContainer.setCenter(centerView);
    }



    public void setMainContainer(BorderPane mainContainer) {
        this.mainContainer = mainContainer;
    }

}
