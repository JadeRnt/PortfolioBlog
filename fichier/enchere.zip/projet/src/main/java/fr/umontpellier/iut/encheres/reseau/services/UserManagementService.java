package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.metier.Cle;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Vendeur;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.Login;
import fr.umontpellier.iut.encheres.reseau.data.SignUp;
import fr.umontpellier.iut.encheres.stockage.Repository.AbstractRepository;

import java.util.ArrayList;
import java.util.Map;

public class UserManagementService {

    protected Map<String, Handler> handlers;

    public UserManagementService(Map<String, Handler> handlers) {
        this.handlers = handlers;
    }

    public void handleLogin(Login login, Handler handler) {
        Login checkedLogin = checkLogin(login);
        if (checkedLogin.getConnectedUser() != null) {
            handler.setUser(checkedLogin.getConnectedUser());
            handlers.put(handler.getClientID(), handler);
            checkedLogin.getConnectedUser().setPublicKey(getPublicKey());
            ClientHandlerInfo handlerInfo = checkedLogin.getConnectedUser().loadPreviousData(handler);
            handler.sendDataToClient(handlerInfo);
        }
        else {
            handler.sendDataToClient(new ClientHandlerInfo(handler.getClientID(), null, new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
        }
    }

    private static SignUp checkSignUp(SignUp signUp) {
        AbstractRepository<Utilisateur> repository = new AbstractRepository<>(Utilisateur.class);
        Utilisateur newUser = repository.recupererParClePrimaire(signUp.getUser().getId());

        if (newUser == null) {
            if (signUp.getUser().getRole().equals("C")) {
                new AbstractRepository<>(Client.class).sauvegarder((Client)signUp.getUser());
            } else {
                (new AbstractRepository<>(Vendeur.class)).sauvegarder((Vendeur)signUp.getUser());
            }
            signUp.setSignUpSuccess(true);
        } else {
            signUp.setSignUpSuccess(false);
        }
        return signUp;
    }


    private Login checkLogin(Login login) {
        Utilisateur connectedUser = new AbstractRepository<>(Utilisateur.class)
                .recupererParClePrimaire(login.getUsername());

        if (connectedUser != null && connectedUser.motDePasseValide(login.getMdp())) {
            login.setConnectedUser(connectedUser);
        }
        return login;
    }

    public void handleSignIn(Handler handler, SignUp signUp) {
        SignUp checkedSignup = checkSignUp(signUp);
        if (checkedSignup.isSignUpSuccess()) {
            handler.setUser(checkedSignup.getUser());
            handlers.put(handler.getClientID(), handler);

            handler.sendDataToClient(new ClientHandlerInfo(handler.getClientID(), checkedSignup.getUser(), new ArrayList<>(),
                    Server.getData().getAuctionsWhereNoBidFromClient(checkedSignup.getUser().getId()),
                    new ArrayList<>()));
        }
        else {
            handler.sendDataToClient(new ClientHandlerInfo(handler.getClientID(), null, new ArrayList<>(), new ArrayList<>(), new ArrayList<>()));
        }
    }

    private Cle getPublicKey() {
        return new AbstractRepository<>(Cle.class).recupererParClePrimaire("clePublique");
    }

    public void deconnectUser(Handler handler) {
        handler.cleanup();
        handlers.remove(handler.getClientID());
    }
}
