package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;

public interface DataWithReturnAction extends Data {

    void executeReturnAction(Service<?> service);
}
