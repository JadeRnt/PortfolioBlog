package fr.umontpellier.iut.encheres.reseau.data;

import java.io.Serializable;

public interface Data extends Serializable {
}
