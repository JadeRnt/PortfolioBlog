package fr.umontpellier.iut.encheres.metier.utilisateurs;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.BCrypt;
import fr.umontpellier.iut.encheres.metier.Cle;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.metier.AbstractDataObject;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.Objects;
@Entity
@Table(name = "SAE_Utilisateurs")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
public abstract class Utilisateur extends AbstractDataObject{
    @Transient
    protected Cle publicKey;

    @Column(length=8192)
    private LocalDate dateNaissance;

    @Id
    private String id;

    @Column(length=8192)
    private String role;

    @Column(length=8192)
    private String mdp;

    @Column(unique = true)
    private String signature;

    /**
     * Construit un utilisateur
     * @param dateNaissance date de naissance
     * @param mdp mot de passe
     * prérequis : l'utilisateur est majeur
     */
    public Utilisateur(String id,  LocalDate dateNaissance, String mdp, String signature) {
        this.id = id;
        this.dateNaissance = dateNaissance;
        this.mdp = mdp;
        this.signature = signature;
    }

    public Utilisateur() {

    }

    public Utilisateur(String id) {
        this.id = id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getId() {
        return id;
    }

    public Utilisateur(String id, String mdp) {
        this.id = id;
        this.mdp = mdp;
    }


    public boolean estAdmin() {
        return (this instanceof AutoriteGestion);
    }

    public boolean estClient() { return (this instanceof Client); }

    public boolean motDePasseValide(String mdp) {
        return BCrypt.checkpw(mdp, this.mdp);
    }


    public abstract void loadUserView(Session session, Service service, ClientHandlerInfo handlerInfo);

    public abstract void saveUser();

    public abstract void loadProductView(Produit product, Session session, Service service);


    public abstract Map<String, String> getTabOptions(Session session, Service service);

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Utilisateur that = (Utilisateur) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }


    public Cle getPublicKey() {
        return publicKey;
    }

    public void setPublicKey(Cle publicKey) {
        this.publicKey = publicKey;
    }

    public ClientHandlerInfo loadPreviousData(Handler handler) {
        return new ClientHandlerInfo(handler.getClientID(), this, new ArrayList<>(), new ArrayList<>(), new ArrayList<>());
    }
}
