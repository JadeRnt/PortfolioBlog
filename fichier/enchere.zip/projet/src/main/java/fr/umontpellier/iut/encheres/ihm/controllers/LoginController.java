package fr.umontpellier.iut.encheres.ihm.controllers;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.UserViewController;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.SocketInfo;
import fr.umontpellier.iut.encheres.reseau.data.Login;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.stage.Popup;
import javafx.util.Duration;

import java.io.File;
import java.io.IOException;


public class LoginController {

    @FXML
    private HBox errorMessage;
    @FXML
    private PasswordField mdp;
    @FXML
    private TextField login;

    private Popup popup;

    int secondsToShow = 5;

    Timeline timeline = new Timeline(new KeyFrame(
            Duration.seconds(secondsToShow),
            event -> errorMessage.setVisible(false)
    ));

    public void initialize() {
        mdp.textProperty().addListener((observable, oldValue, newValue) -> {
            if (errorMessage.isVisible()) {
                errorMessage.setVisible(false);
            }
        });

    }

    @FXML
    public void handleLogin() {
        SocketInfo socket = new SocketInfo();

        Login loginTry = new Login(mdp.getText(), login.getText());
        socket.sendData(loginTry);

        // Receive handler ID
        Object data = socket.receiveData();
        if (data instanceof ClientHandlerInfo) {

            try {
                ((ClientHandlerInfo)data).getConnectedUser().loadUserView(new Session(((ClientHandlerInfo)data).getConnectedUser(), socket, ((ClientHandlerInfo)data).getClientID()), new Service(), (ClientHandlerInfo)data);
            }
            catch (Exception e){
                errorMessage.setVisible(true);
                timeline.playFromStart();
            }
        }
    }



    @FXML
    public void loadSignUpView() {
        (new UserViewController()).loadSignUpView();
    }

    @FXML
    public void showPopup() {
        try {
            File pdfFile = new File("src/resources/CGU.pdf");

            // Use ProcessBuilder to open the default PDF viewer with the local PDF file
            String os = System.getProperty("os.name").toLowerCase();

            ProcessBuilder processBuilder;
            if (os.contains("win")) {
                processBuilder = new ProcessBuilder("cmd", "/c", "start", "\"\"", pdfFile.getAbsolutePath());
            } else if (os.contains("nix") || os.contains("nux") || os.contains("mac")) {
                processBuilder = new ProcessBuilder("xdg-open", pdfFile.getAbsolutePath());
            } else {
                throw new UnsupportedOperationException("Unsupported operating system");
            }

            processBuilder.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

}
