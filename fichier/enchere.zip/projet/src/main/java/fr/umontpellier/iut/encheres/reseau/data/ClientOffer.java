package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.ClientOfferTransmittedListener;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Vendeur;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

public class ClientOffer implements DataWithReturnAction, DataAction {

    private final Offre offer;


    public ClientOffer(Offre offer) {
        this.offer = offer;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.sendOfferToSeller(handler, this);
    }

    public Vendeur getSeller() {return offer.getProduct().getSeller();}

    @Override
    public void executeReturnAction(Service<?> service) {
        ((ClientOfferTransmittedListener) service.getController()).onClientOfferTransmitted(this);
    }

    public Offre getOffer() {
        return offer;
    }
}
