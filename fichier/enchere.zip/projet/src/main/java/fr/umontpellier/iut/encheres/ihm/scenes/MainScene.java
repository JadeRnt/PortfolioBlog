package fr.umontpellier.iut.encheres.ihm.scenes;

import fr.umontpellier.iut.encheres.ihm.controllers.views.MainController;

public class MainScene {

    private static MainController mainController;

    public static MainController getMain() {
        return mainController;
    }

    public static void setMainController(MainController main) {
        mainController = main;
    }
}
