package fr.umontpellier.iut.encheres.stockage.Local.Serveur;

import fr.umontpellier.iut.encheres.metier.Offre;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Offers {

    private final Set<Offre> currentClientOffers = new HashSet<>();

    protected List<Offre> getOffersMadeByClient(String clientID) {
        List<Offre> offers = new ArrayList<>();
        for(Offre offer : currentClientOffers) {
            if (offer.getClient().getId().equals(clientID)) {
                offers.add(offer);
            }
        }
        return offers;
    }

    protected void addOffer(Offre offer) {
        currentClientOffers.add(offer);
    }

    public Set<Offre> getCurrentClientOffers() {
        return currentClientOffers;
    }
}
