package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.ihm.Service;

public interface Listener {
    void notifyUser(Service<?> service);
}
