package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.client;

import fr.umontpellier.iut.encheres.ihm.listeners.AuctionEndedListener;
import fr.umontpellier.iut.encheres.ihm.setupStrategy.ProductGridSetupStrategy;
import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserListProductController;
import fr.umontpellier.iut.encheres.ihm.listeners.AuctionStartedListener;
import fr.umontpellier.iut.encheres.ihm.listeners.ResultListener;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Client;
import fr.umontpellier.iut.encheres.reseau.data.AuctionStarted;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import javafx.application.Platform;

import java.util.Map;

public class ListProductControllerClient extends NotifyUserListProductController implements
        AuctionStartedListener, ResultListener,
        AuctionEndedListener {

    @Override
    public void setParameters(Map<String, Object> parameters) {
        super.setParameters(parameters);
        setUpService(this);
        ClientHandlerInfo handlerInfo = (ClientHandlerInfo) parameters.get("handlerInfo");
        ProductGridSetupStrategy strategy = (ProductGridSetupStrategy) parameters.get("setupStrategy");
        strategy.setUpProductGrid(this, (Client)getSession().getConnectedUser(), handlerInfo);
    }

    @Override
    public void onAuctionStarted(AuctionStarted auctionStarted) {
        allowCreateOffer(auctionStarted.getAuction().getProduit());
    }

    public void allowCreateOffer(Produit product) {
        Platform.runLater(() -> {
            super.updateProductGrid(product);
            setAlertMessage("Une enchère a été démarré sur un produit ! Cliquez dessus pour pouvoir enchérir");
        });
    }


    @Override
    public void onResultReceived(Message message) {
        ((ResultController) Scenes.getScene(message.getProductConcerned().getIdProduit()).getController()).onResultReceived(message);
        Platform.runLater(() -> setAlertMessage("Vous avez reçu le résultat d'une enchère!"));
    }

    @Override
    public void onAuctionEnded(Produit produit) {
        removeFromGrid(produit.getIdProduit());
        setAlertMessage("Une enchère a été fermé sur un produit!");
    }
}
