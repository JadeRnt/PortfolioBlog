package fr.umontpellier.iut.encheres.reseau;

import fr.umontpellier.iut.encheres.stockage.Local.Serveur.ServerData;
import fr.umontpellier.iut.encheres.utils.JSSE;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import java.io.IOException;
import java.net.Socket;
import java.util.concurrent.ConcurrentHashMap;

public class Server {

    protected static final String ADMIN_ID = "3567";
    private static final int PORT = 8888;

    private static final ServerData DATA = new ServerData();

    protected static final ConcurrentHashMap<String, Handler> handlers = new ConcurrentHashMap<>();

    public static void main(String[] args) throws IOException {
        JSSE.configurationKeyStore("src/resources/keystore/keystore.jks", "secureSockets");
        JSSE.configurationTrustStore("src/resources/truststore/truststore.jks", "secureSockets");

        SSLServerSocketFactory sslServerSocketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        SSLServerSocket serverSocket = (SSLServerSocket) sslServerSocketFactory.createServerSocket(PORT);
        serverSocket.setEnabledCipherSuites(new String[]{"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"});
        System.out.println("Server started");
        try {

            while (true) {
                Socket clientSocket = serverSocket.accept();
                String clientID = "Client_" + System.currentTimeMillis();
                Handler handler = new Handler(clientSocket, clientID);
                new Thread(handler).start();
            }
        }
        catch (ExceptionInInitializerError e) {
            e.printStackTrace();
        }
    }


    public static ServerData getData() { return DATA; }

    public static ConcurrentHashMap<String, Handler> getHandlers() {
        return handlers;
    }

}
