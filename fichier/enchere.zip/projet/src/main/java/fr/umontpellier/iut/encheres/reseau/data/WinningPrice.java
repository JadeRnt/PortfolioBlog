package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.WinningOfferTransmitedListener;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;
import javafx.application.Platform;

public class WinningPrice implements DataWithReturnAction, DataAction {

    private final String encryptedPrice;

    private final Produit productConcerned;
    private final Integer priceToPay;

    private boolean transmissionSuccess = false;


    public WinningPrice(String encryptedPrice, Produit product, Integer priceToPay) {
        this.encryptedPrice = encryptedPrice;
        productConcerned = product;
        this.priceToPay = priceToPay;
    }


    public void setTransmissionSuccess(boolean transmissionSuccess) {
        this.transmissionSuccess = transmissionSuccess;
    }

    public String getProductID() {
        return productConcerned.getIdProduit();
    }


    public Produit getProductConcerned() {
        return productConcerned;
    }

    public String getEncryptedPrice() {
        return encryptedPrice;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.transmitWinningOffer(this, handler);
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        Platform.runLater(() -> {
            WinningOfferTransmitedListener controller = (WinningOfferTransmitedListener) service.getController();
            controller.onWinningOfferTransmitted(this);
        });
    }

    public Integer getPriceToPay() {
        return priceToPay;
    }
}