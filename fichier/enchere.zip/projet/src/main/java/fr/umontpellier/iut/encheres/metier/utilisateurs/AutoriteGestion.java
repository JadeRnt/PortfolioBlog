package fr.umontpellier.iut.encheres.metier.utilisateurs;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.controllers.views.users.AdminViewController;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.setup.ClientHandlerInfo;
import fr.umontpellier.iut.encheres.reseau.data.setup.HandlerInfo;
import fr.umontpellier.iut.encheres.utils.KeyUtils;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.utils.SignaturePair;
import jakarta.persistence.Entity;
import jakarta.persistence.Transient;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import java.security.*;
import java.util.*;

/*
Create AGE :

INSERT INTO SAE_Utilisateurs (dtype, id, role, dateNaissance, nom, prenom, mdp, signature) VALUES ('AGE', '0', 'A', '19/12/01', 'Admin', 'Admin', 'admin', 'D91FeAAQ9uvxhph7nnSS95eqNWPUVgZ9YOQVScx00uBHogO2am1h213YAPqGTd7BVp63OH5isOmuJwIjrMMqz0v4v91PEyc9upyktnv4y0rPVwcle4HKYBf8XgSSbPLrITfFjl0mFtbFbcyKK9aNuvht5zKq1W6vvUBc5BflxwES0yy9SZBEEX3qNLE8DaqEyTMDR3zyv0x71uLQ740kvOOSmWjUZ7Skdomox2w')
 */
@Entity(name="AGE")
public class AutoriteGestion extends Utilisateur {

    private static PrivateKey clePrivee;


    public AutoriteGestion() {
        getKeys();
    }



    /**
     * @param offreChiffreeBase64 l'enchère chiffrée
     * @return l'enchère déchiffrée
     * les exceptions ne sont là qu'à cause de la classe Cipher qui nous oblige à les mettre
     */
    public Integer dechiffrerEnchere(String offreChiffreeBase64) throws InvalidKeyException, IllegalBlockSizeException, BadPaddingException, NoSuchPaddingException, NoSuchAlgorithmException {
        Cipher dechiffreur = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        getKeys();
        dechiffreur.init(Cipher.DECRYPT_MODE, AutoriteGestion.clePrivee);
        byte[] texteChiffre = Base64.getDecoder().decode(offreChiffreeBase64);
        byte[] texteDechiffre = dechiffreur.doFinal(texteChiffre);
        String texteDechiffreStr = new String(texteDechiffre);
        return Integer.parseInt(texteDechiffreStr);
    }


    private void getKeys() {
        SignaturePair pair = KeyUtils.generateSignatures();
        clePrivee = pair.getPrivateKey();
    }

    @Override
    public void saveUser() {

    }

    @Override
    public void loadProductView(Produit product, Session session, Service service) {
        new AdminViewController().loadStartBiddingView(product, session);
    }

    @Override
    public void loadUserView(Session session, Service service, ClientHandlerInfo handlerInfo) {
        new AdminViewController().loadAdminView(session, service);
    }

    @Transient
    @Override
    public Map<String, String> getTabOptions(Session session, Service service) {
        Map<String, String> tabs = new HashMap<>();
        tabs.put("Catalogue", "list");
        return tabs;
    }
}

