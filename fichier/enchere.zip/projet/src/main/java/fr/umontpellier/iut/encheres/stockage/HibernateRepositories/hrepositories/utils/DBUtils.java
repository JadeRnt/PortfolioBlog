//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.utils;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

public class DBUtils {
    private static SessionFactory sessionFactory;

    public DBUtils() {
    }

    public static Session getSession() {
        return sessionFactory.openSession();
    }

    static {
        try {
            StandardServiceRegistry registry = (new StandardServiceRegistryBuilder()).configure().build();
            sessionFactory = (new MetadataSources(registry)).buildMetadata().buildSessionFactory();
        }
        catch (ExceptionInInitializerError | IllegalStateException e) {
            System.out.println("Je n'arrive pas à me connecter à la base de données");
        }

    }
}
