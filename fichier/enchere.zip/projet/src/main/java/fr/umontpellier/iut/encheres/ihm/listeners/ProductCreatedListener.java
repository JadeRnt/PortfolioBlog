package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.CreateProduct;

public interface ProductCreatedListener extends Listener{
    public void onProductCreated(CreateProduct productCreated);
}
