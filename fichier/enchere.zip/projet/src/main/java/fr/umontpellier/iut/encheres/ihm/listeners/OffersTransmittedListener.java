package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.Prices;

public interface OffersTransmittedListener extends Listener {

    public abstract void onOffersTransmitted(Prices prices);
}
