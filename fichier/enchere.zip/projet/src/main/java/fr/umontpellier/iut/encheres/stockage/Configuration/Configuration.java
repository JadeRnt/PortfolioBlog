package fr.umontpellier.iut.encheres.stockage.Configuration;
public class Configuration {

    private static final String login = "lewisc";
    private static final String password = "20052004";

    public static String getLogin() {
        return login;
    }


    public static String getPassword() {
        return password;
    }
}