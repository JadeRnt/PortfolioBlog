package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.AuctionStarted;

public interface AuctionStartedListener {

    public abstract void onAuctionStarted(AuctionStarted auctionStarted);
}
