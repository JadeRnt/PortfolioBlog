package fr.umontpellier.iut.encheres.reseau;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;

public class Session {

    private Utilisateur connectedUser;
    private SocketInfo socket;

    private String handlerID;

    public Session(Utilisateur connectedUser, SocketInfo socket, String handler) {
        this.connectedUser = connectedUser;
        this.socket = socket;
        handlerID = handler;
    }

    public Utilisateur getConnectedUser() {
        return connectedUser;
    }

    public SocketInfo getSocket() {
        return socket;
    }

    public String getHandlerID() {
        return handlerID;
    }
}
