package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.admin;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserController;
import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.*;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.metier.utilisateurs.AutoriteGestion;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;

import java.time.Duration;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class AuctionController extends NotifyUserController {


    @FXML
    private VBox buttons;

    @FXML
    private Text title, productID, description, periodLabel;


    @FXML
    private Button openBtn, closeBtn, operationsBtn;

    @FXML
    private VBox pricesContainer;

    private Produit product;
    private Session session;

    private Integer winningOffer;
    private Integer priceToPay;
    private PriceWithDate correspondingWinningPriceWithDate;

    @FXML
    private TextField hoursInput, minutesInput;
    private Duration auctionDuration;

    public void initialize(){
        // Default value for an auction
        auctionDuration = Duration.ofHours(24);
        closeBtn.setVisible(false);
    }

    @FXML
    public void startBidding() {
        try {
            int hours = Integer.parseInt(hoursInput.getText());
            int minutes = Integer.parseInt(minutesInput.getText());

            auctionDuration = Duration.ofHours(hours).plusMinutes(minutes);

            if (auctionDuration.toMillis() < 0) {
                throw new NumberFormatException();
            }

            session.getSocket().sendData(new AuctionStarted(new Enchere(product, auctionDuration)));
        } catch (NumberFormatException e) {
            // Handle invalid input (e.g., show an alert)
            setAlertMessage("Heure/Minute invalide");

        }

    }

    public void confirmAuctionStarted(AuctionStarted auctionStarted) {
        if (auctionStarted.auctionStarted()) {
            hoursInput.setVisible(false);
            minutesInput.setVisible(false);
            periodLabel.setVisible(false);
            openBtn.setVisible(false);
            setAlertMessage("L'enchère a démarré sur ce produit");
            closeBtn.setVisible(true);
        }
    }

    @FXML
    public void closeBidding() {
        session.getSocket().sendData(new AuctionEnded(product));
        closeBtn.setVisible(false);
        setAlertMessage("L'enchère a été fermé !");
    }


    @Override
    public void setParameters(Map<String, Object> parameters) {
        product = (Produit) parameters.get("produit");
        title.setText(product.getTitle());
        productID.setText(product.getIdProduit());
        description.setText(product.getDescription());
        session = (Session) parameters.get("session");
    }

    @Override
    public Session getSession() {
        return session;
    }

    public void createLabels(List<PriceWithDate> prices) {
        int count = 0;
        for (PriceWithDate price : prices) {
            count ++;
            Integer prix;
            try {
                prix = ((AutoriteGestion)session.getConnectedUser()).dechiffrerEnchere(price.getPrice());

                // Cas où aucun gagnant n'a été sélectionné encore
                if (winningOffer==null) {
                    winningOffer = prix;
                    correspondingWinningPriceWithDate = price;
                    // Cas où on n'a pas de deuxième montant possible
                    if (prices.size()==1) {
                        priceToPay = prix;
                    }
                }
                // Cas où deux clients ont mis le même montant
                else if (winningOffer.equals(prix)) {
                    // Cas (très peu probable) où les offres ont été soumis au même moment (à la seconde près)
                    if (correspondingWinningPriceWithDate.getDate().isEqual(price.getDate())) {
                        Random random = new Random();
                        int randomNumber = random.nextInt(2);
                        PriceWithDate chosenObject = (randomNumber == 0) ? correspondingWinningPriceWithDate : price;
                        if (!chosenObject.equals(correspondingWinningPriceWithDate)) {
                            correspondingWinningPriceWithDate = price;
                            winningOffer = prix;
                        }
                    }

                    // Cas où on compare les dates et temps pour prendre l'offre qui a été soumis en premier
                    else if (correspondingWinningPriceWithDate.getDate().isAfter(price.getDate())) {
                        winningOffer = prix;
                        correspondingWinningPriceWithDate = price;
                    }

                    // Cas où il n'y a que deux offres avec le même prix
                    if (prices.size()==2) {
                        priceToPay = prix;
                    }
                }
                // Si le prix n'est pas gagnant et qu'on n'a pas déterminé le prix à payer
                else if (priceToPay == null) {
                    priceToPay = prix;
                }
                // Si le prix n'est pas gagnant et que l'on a déjà déterminé le prix à payer
                else if (priceToPay < prix) {
                    priceToPay = prix;
                }

            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            Label label = new Label(count + " : " + prix);
            pricesContainer.getChildren().add(label);
        }
        operationsBtn = new Button();
        operationsBtn.setText("Obtenir les montants déchiffrés");
        operationsBtn.setOnAction(event -> showPrices());
        buttons.getChildren().add(operationsBtn);
    }

    public void showPrices() {
        pricesContainer.setVisible(true);
        operationsBtn.setText("Trouver le montant gagnant");
        operationsBtn.setOnAction(event -> findWinner());
    }

    public void findWinner() {
        pricesContainer.getChildren().removeIf(label -> {
            String accessibleText = label.getAccessibleText();
            return accessibleText != null && !accessibleText.contains(Integer.toString(winningOffer));
        });
        operationsBtn.setText("Transmettre l'offre gagnant au vendeur");
        operationsBtn.setOnAction(event -> transmitWinningOffer());
    }

    public void transmitWinningOffer() {
        session.getSocket().sendData(new WinningPrice(correspondingWinningPriceWithDate.getPrice(), product, priceToPay));
        operationsBtn.setVisible(false);
    }



    public void setProduct(Produit product) {
        this.product = product;
    }

    public void onOffersTransmitted(Prices prices) {
        Platform.runLater(() -> createLabels(prices.getPrices()));
    }


    public void onWinningOfferTransmitted(WinningPrice data) {
        //TODO : do something
    }

    public void auctionEnded() {
        if (closeBtn.isVisible()) {
            closeBidding();
        }
    }

}
