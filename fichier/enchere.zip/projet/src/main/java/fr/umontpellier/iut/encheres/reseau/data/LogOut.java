package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

public class LogOut implements DataAction{

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        Thread thread = new Thread(() ->  context.deconnectUser(handler));
        thread.start();
    }

}
