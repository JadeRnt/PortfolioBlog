package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.ReturnProduct;

public interface ReturnProductListener extends Listener {

    void onProductReturned(ReturnProduct returnProduct);
}
