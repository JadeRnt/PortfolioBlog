package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.client;

import fr.umontpellier.iut.encheres.ihm.controllers.views.users.ClientViewController;
import fr.umontpellier.iut.encheres.ihm.listeners.Listener;
import fr.umontpellier.iut.encheres.ihm.scenes.CenterView;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import fr.umontpellier.iut.encheres.reseau.data.Results;
import javafx.scene.control.Label;

import java.util.List;


public class OfferController extends ListProductControllerClient {

    private List<Message> messages;

    @Override
    protected Label getLabel(Object object) {
        Offre offer = (Offre) object;
        Label label = new Label(offer.getProduct().getTitle());
        Message winningMessage = null;

        if(messages!=null) {
            for(Message message : messages) {
                if (message.getProductConcerned().getIdProduit().equals(offer.getProduct().getIdProduit())) {
                    winningMessage = message;
                    break;
                }
            }
        }

        new ClientViewController().loadResultsView(getSession(), service, offer, winningMessage);
        if (winningMessage !=null) {
            ((ResultController) Scenes.getScene(winningMessage.getProductConcerned().getIdProduit()).getController()).onResultReceived(winningMessage);
        }
        CenterView view = Scenes.getScene(offer.getProduct().getIdProduit());
        action(label, view);
        return label;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    @Override
    protected void setUpService(Listener listener) {

    }
}
