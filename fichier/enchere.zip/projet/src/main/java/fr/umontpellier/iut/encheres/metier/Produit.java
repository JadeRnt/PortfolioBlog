package fr.umontpellier.iut.encheres.metier;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Vendeur;

import java.util.Objects;


public class Produit extends AbstractDataObject{

    private Vendeur vendeur;


    private String idProduit;

    private String description;

    private String title;


    public Produit(Vendeur vendeur, String id, String description, String title) {
        this.idProduit = id;
        this.description = description;
        this.vendeur = vendeur;
        this.title = title;
    }

    public Produit() {

    }


    public String getDescription() {
        return description;
    }

    public Vendeur getSeller() {
        return vendeur;
    }

    public String getIdProduit() {
        return idProduit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produit produit = (Produit) o;
        return idProduit == produit.idProduit;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idProduit);
    }

    public String getTitle() {
        return title;
    }
}