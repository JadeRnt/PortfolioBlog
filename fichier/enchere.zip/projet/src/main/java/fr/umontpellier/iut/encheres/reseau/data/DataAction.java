package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

public interface DataAction extends Data {

    void executeAction(ServerContext context, Handler handler);

}
