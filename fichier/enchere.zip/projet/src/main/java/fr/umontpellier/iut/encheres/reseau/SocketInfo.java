package fr.umontpellier.iut.encheres.reseau;


import fr.umontpellier.iut.encheres.utils.JSSE;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.net.SocketTimeoutException;

public class SocketInfo {

    private static final int PORT = 8888;

    private ObjectInputStream input;
    private ObjectOutputStream output;
    private SSLSocket socket;

    public SocketInfo() {
        try {
            JSSE.configurationKeyStore("src/resources/keystore/keystore.jks", "secureSockets");
            JSSE.configurationTrustStore("src/resources/truststore/truststore.jks", "secureSockets");

            SSLSocketFactory sslSocketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            this.socket = (SSLSocket) sslSocketFactory.createSocket("localhost", PORT);
            this.socket.setEnabledCipherSuites(new String[]{"TLS_ECDHE_RSA_WITH_AES_128_CBC_SHA256"});
            output = new ObjectOutputStream(socket.getOutputStream());
            input = new ObjectInputStream(socket.getInputStream());
        }
        catch (IOException e) {
            e.printStackTrace();
            close();
        }

    }

    public void sendData(Object data) {
        try {
            output.writeObject(data);
            output.flush();
        }
        catch (IOException e) {
            close();
        }
    }

    public Object receiveData() {
        try {
            return input.readObject();
        }
        catch (ClassNotFoundException | IOException e) {
            System.out.println("Data not received");
        }
        return null;
    }

    public void close() {
        try {
            socket.close();
            input.close();
            output.close();
        }
        catch (IOException e) {
            System.out.println("Error closing socket");
        }
    }

}
