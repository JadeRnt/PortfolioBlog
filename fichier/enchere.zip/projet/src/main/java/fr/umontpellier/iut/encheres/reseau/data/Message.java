package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.ResultListener;
import fr.umontpellier.iut.encheres.metier.Produit;
import javafx.application.Platform;


public class Message implements DataWithReturnAction {

    private final String message;
    private final Produit productConcerned;

    public Message(String message, Produit product) {
        this.message = message;
        productConcerned = product;
    }

    public String getMessage() {
        return message;
    }

    public Produit getProductConcerned() {
        return productConcerned;
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        Platform.runLater(()-> {
            ((ResultListener)service.getController()).onResultReceived(this);
        });
    }
}
