package fr.umontpellier.iut.encheres.ihm.controllers.parametrable;


import fr.umontpellier.iut.encheres.reseau.Session;
import java.util.Map;

public interface ParametrableController  {

    void setParameters(Map<String, Object> parameters);

    Session getSession();
}
