package fr.umontpellier.iut.encheres.metier;

import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.id.IncrementGenerator;

@Entity
@Table(name = "SAE_Cles")
public class Cle extends AbstractDataObject{

    @Id
    private String idCle;
    @Column(length=24080)
    private String cle;

    public Cle(String idCle, String cle) {
        this.idCle = idCle;
        this.cle = cle;
    }

    public Cle() {

    }

    public String getCle() {
        return cle;
    }

}
