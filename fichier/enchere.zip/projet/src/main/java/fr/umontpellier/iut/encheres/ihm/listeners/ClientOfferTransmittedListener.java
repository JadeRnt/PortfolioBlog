package fr.umontpellier.iut.encheres.ihm.listeners;

import fr.umontpellier.iut.encheres.reseau.data.ClientOffer;

public interface ClientOfferTransmittedListener extends Listener{

    public void onClientOfferTransmitted(ClientOffer offer);
}
