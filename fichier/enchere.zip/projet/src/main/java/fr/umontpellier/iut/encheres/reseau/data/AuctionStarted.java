package fr.umontpellier.iut.encheres.reseau.data;

import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.listeners.AuctionStartedListener;
import fr.umontpellier.iut.encheres.metier.Enchere;
import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

public class AuctionStarted implements DataWithReturnAction, DataAction {

    private final Enchere auction;
    private boolean auctionStarted;

    public boolean auctionStarted() {
        return auctionStarted;
    }

    public void setAuctionStarted() {
        this.auctionStarted = true;
    }

    public Enchere getAuction() {
        return auction;
    }

    public AuctionStarted(Enchere auction) {
        this.auction = auction;
    }

    @Override
    public void executeAction(ServerContext context, Handler handler) {
        context.transmitAuctionStartedSignal(handler, this);
    }

    @Override
    public void executeReturnAction(Service<?> service) {
        ((AuctionStartedListener) service.getController()).onAuctionStarted(this);
    }

}
