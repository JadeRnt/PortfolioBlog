package fr.umontpellier.iut.encheres.reseau;

import fr.umontpellier.iut.encheres.reseau.data.DataAction;
import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.reseau.services.ServerContext;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Handler implements Runnable {
    private final String clientID;
    private final Socket clientSocket;

    private Utilisateur user;
    private ObjectInputStream in;
    private ObjectOutputStream out;


    public Handler(Socket clientSocket, String clientID) {

        this.clientSocket = clientSocket;
        this.clientID = clientID;
    }

    @Override
    public void run() {
        try {
            // Initialize input and output streams
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            in = new ObjectInputStream(clientSocket.getInputStream());

            while (true) {
                // Read data from the client
                Object data = in.readObject();

                processData(data);
            }
        } catch (IOException | ClassNotFoundException e) {
            cleanup();
        }
    }


    private void processData(Object data) {
        if (data instanceof DataAction) {
            ((DataAction) data).executeAction(new ServerContext(Server.handlers), this);
        }
    }

    public String getClientID() {
        return clientID;
    }

    public Utilisateur getUser() {
        return user;
    }

    public void setUser(Utilisateur user) {
        this.user = user;
    }

    public void sendDataToClient(Object data) {
        try {
            // Send data to the client
            out.writeObject(data);
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cleanup() {
        try {
            // Close resources
            if (out != null) out.close();
            if (in != null) in.close();
            clientSocket.close();

            // Remove this client handler from the server's map
            Server.handlers.remove(clientID);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
