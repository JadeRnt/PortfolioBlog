package fr.umontpellier.iut.encheres.metier;


import jakarta.persistence.MappedSuperclass;

import java.io.Serializable;

@MappedSuperclass
public abstract class AbstractDataObject implements Serializable {

}
