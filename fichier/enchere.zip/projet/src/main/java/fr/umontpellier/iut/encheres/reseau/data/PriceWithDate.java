package fr.umontpellier.iut.encheres.reseau.data;

import java.time.LocalDateTime;
import java.util.Date;

public class PriceWithDate implements Data {

    private final String price;
    private final LocalDateTime date;

    public PriceWithDate(String price, LocalDateTime date) {
        this.price = price;
        this.date = date;
    }

    public String getPrice() {
        return price;
    }

    public LocalDateTime getDate() {
        return date;
    }
}
