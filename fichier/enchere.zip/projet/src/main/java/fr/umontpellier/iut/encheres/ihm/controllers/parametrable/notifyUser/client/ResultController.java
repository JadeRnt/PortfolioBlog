package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.client;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserController;
import fr.umontpellier.iut.encheres.ihm.listeners.ResultListener;
import fr.umontpellier.iut.encheres.metier.Offre;
import fr.umontpellier.iut.encheres.reseau.Session;
import fr.umontpellier.iut.encheres.reseau.data.Message;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

import java.util.Map;

public class ResultController extends NotifyUserController implements ResultListener {

    @FXML
    private Text idProduct, description, message;

    @FXML
    private Button resultBtn;

    @Override
    public void setParameters(Map<String, Object> parameters) {
        Offre offer = (Offre) parameters.get("offer");
        idProduct.setText(offer.getProduct().getTitle());
        description.setText(offer.getProduct().getDescription());
        if(parameters.get("message")!=null){
            onResultReceived((Message) parameters.get("message"));
        }
    }

    @Override
    public Session getSession() {
        return null;
    }

    @Override
    public void onResultReceived(Message message) {
        this.message.setText(message.getMessage());
        resultBtn.setVisible(true);
    }

    public void showResult() {
        message.setVisible(true);
    }
}
