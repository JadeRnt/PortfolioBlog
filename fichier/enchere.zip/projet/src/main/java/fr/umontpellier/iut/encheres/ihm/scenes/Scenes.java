package fr.umontpellier.iut.encheres.ihm.scenes;

import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.ParametrableController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Scenes {

    private final Map<String, CenterView> list;
    private static Scenes INSTANCE;

    private Scenes() {
        list = new HashMap<>();
    }


    private static Scenes getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new Scenes();
        }
        return INSTANCE;
    }

    public static CenterView uploadCenterView(String sceneID, String viewPath, Map<String, Object> parameters) {
        Scenes scenes = getInstance();
        if (!scenes.list.containsKey(sceneID)) {
            FXMLLoader loader = new FXMLLoader(Scenes.class.getResource(viewPath));
            try {
                Node center = loader.load();
                ParametrableController controller = loader.getController();
                controller.setParameters(parameters);
                scenes.list.put(sceneID, new CenterView(center, controller));
                return new CenterView(center, controller);
            }
            catch (IOException e) {
                e.printStackTrace();
            }
        }
        else {
            throw new RuntimeException("The scene has already been loaded once !");
        }
        return null;
    }

    public static CenterView getScene(String sceneID) {
        return getInstance().list.get(sceneID);
    }

    public static void removeScene(String sceneID) { getInstance().list.remove(sceneID);}
    public static void removeAllScenes() {
        INSTANCE = null;
    }

}
