package fr.umontpellier.iut.encheres.ihm;

import javafx.stage.Stage;

public class StageManager {

    private static final StageManager INSTANCE = new StageManager();
    private Stage currentStage;

    private StageManager() {
    }

    public static StageManager getInstance() {
        return INSTANCE;
    }

    public void setCurrentStage(Stage stage) {
        currentStage = stage;
    }

    public Stage getCurrentStage() {
        return currentStage;
    }



}