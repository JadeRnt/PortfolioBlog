package fr.umontpellier.iut.encheres.reseau.services;

import fr.umontpellier.iut.encheres.reseau.Handler;
import fr.umontpellier.iut.encheres.reseau.Server;
import fr.umontpellier.iut.encheres.reseau.data.AuctionEnded;
import fr.umontpellier.iut.encheres.reseau.data.AuctionStarted;

import java.util.Map;

public class AuctionService {

    protected Map<String, Handler> handlers;

    public AuctionService(Map<String, Handler> handlers) {
        this.handlers = handlers;
    }

    public void transmitAuctionEndedSignal(AuctionEnded auctionEnded) {
        Handler handler = ConnectedCheck.userConnected(handlers, auctionEnded.getProduct().getSeller());
        if (handler != null) {
            Server.getData().removeAuction(auctionEnded.getProduct());
            handler.sendDataToClient(auctionEnded);
            for (Map.Entry<String, Handler> connexion : handlers.entrySet()) {
                if (connexion.getValue().getUser().estClient()) {
                    connexion.getValue().sendDataToClient(auctionEnded);
                }
            }
        }
    }

    public void transmitAuctionStartedSignal(Handler handler, AuctionStarted auctionStarted) {
        Server.getData().addAuction(auctionStarted.getAuction());
        for (Map.Entry<String, Handler> connexion : handlers.entrySet()) {
            if (connexion.getValue().getUser().estClient()) {
                connexion.getValue().sendDataToClient(auctionStarted);
            }
        }
        auctionStarted.setAuctionStarted();
        handler.sendDataToClient(auctionStarted);
    }
}
