package fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.seller;

import fr.umontpellier.iut.encheres.ihm.listeners.*;
import fr.umontpellier.iut.encheres.ihm.controllers.parametrable.notifyUser.NotifyUserListProductController;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import fr.umontpellier.iut.encheres.metier.Produit;
import fr.umontpellier.iut.encheres.reseau.data.ClientOffer;
import fr.umontpellier.iut.encheres.reseau.data.CreateProduct;
import fr.umontpellier.iut.encheres.reseau.data.Prices;
import fr.umontpellier.iut.encheres.reseau.data.WinningPrice;
import javafx.application.Platform;

import java.util.Map;


public class ListProductControllerVendeur extends NotifyUserListProductController implements AuctionEndedListener, WinningOfferTransmitedListener,
        ClientOfferTransmittedListener, ProductCreatedListener,
        OffersTransmittedListener {


    @Override
    public void onAuctionEnded(Produit product) {
        setAlertMessage("Une enchère a été fermé, cliquez sur le produit pour déterminer le gagnant !");
        ((GetOffersController) Scenes.getScene(product.getIdProduit()).getController()).onAuctionEnded(product);
    }

    @Override
    public void setParameters(Map<String, Object> parameters) {
        super.setParameters(parameters);
        setUpService(this);
    }

    @Override
    public void onWinningOfferTransmitted(WinningPrice data) {
        ((GetOffersController) Scenes.getScene(data.getProductID()).getController()).onWinningOfferTransmitted(data);
    }

    @Override
    public void onClientOfferTransmitted(ClientOffer offer) {
        ((GetOffersController) Scenes.getScene(offer.getOffer().getProduct().getIdProduit()).getController()).onClientOfferTransmitted(offer);
    }

    @Override
    public void onProductCreated(CreateProduct productCreated) {

        Platform.runLater(()-> {
            updateProductGrid(productCreated.getProduct());
            ((CreateProductController) Scenes.getScene("create").getController()).onProductCreated(productCreated);
        });
    }

    @Override
    public void onOffersTransmitted(Prices prices) {
        ((GetOffersController) Scenes.getScene(prices.getProduct().getIdProduit()).getController()).onOffersTransmitted(prices);
    }

}



