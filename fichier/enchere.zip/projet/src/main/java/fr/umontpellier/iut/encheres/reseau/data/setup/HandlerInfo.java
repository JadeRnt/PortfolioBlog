package fr.umontpellier.iut.encheres.reseau.data.setup;

import fr.umontpellier.iut.encheres.metier.utilisateurs.Utilisateur;
import fr.umontpellier.iut.encheres.reseau.data.Data;

public class HandlerInfo implements Data {

    private final String clientID;

    private final Utilisateur connectedUser;

    public String getClientID() {
        return clientID;
    }

    public HandlerInfo(String clientID, Utilisateur connectedUser) {
        this.clientID = clientID;
        this.connectedUser = connectedUser;
    }


    public Utilisateur getConnectedUser() {
        return connectedUser;
    }


}
