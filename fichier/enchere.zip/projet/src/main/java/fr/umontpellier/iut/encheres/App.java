package fr.umontpellier.iut.encheres;

import fr.umontpellier.iut.encheres.ihm.StageManager;
import fr.umontpellier.iut.encheres.ihm.controllers.BCrypt;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {

    public static void main(String[] args) {
        Application.launch(args);
    }


    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getClassLoader().getResource("views/loginView.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        scene.getStylesheets().add(getClass().getClassLoader().getResource("login.css").toExternalForm());
        stage.setScene(scene);
        stage.setTitle("Application d'enchères");
        StageManager.getInstance().setCurrentStage(stage);
        stage.setResizable(false);
        stage.show();
    }
}
