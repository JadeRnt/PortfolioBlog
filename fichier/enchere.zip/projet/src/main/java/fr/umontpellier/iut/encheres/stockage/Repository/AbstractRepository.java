package fr.umontpellier.iut.encheres.stockage.Repository;

import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.api.EntityRepository;
import fr.umontpellier.iut.encheres.stockage.HibernateRepositories.hrepositories.utils.RepositoryManager;
import fr.umontpellier.iut.encheres.metier.AbstractDataObject;

import java.util.List;

public class AbstractRepository<T extends AbstractDataObject> {

    private final EntityRepository<T> abstractRepository;

    public AbstractRepository(Class<T> entityClass) {
        this.abstractRepository = RepositoryManager.getRepository(entityClass);
    }

    public void mettreAJour(T object) {
        abstractRepository.update(object);
    }

    public void sauvegarder(T object) {
        abstractRepository.create(object);
    }

    public T recupererParClePrimaire(Object valeurClePrimaire) {
        return abstractRepository.findByID(valeurClePrimaire);
    }

}