package fr.umontpellier.iut.encheres.ihm.controllers.views.users;


import fr.umontpellier.iut.encheres.ihm.Service;
import fr.umontpellier.iut.encheres.ihm.StageManager;
import fr.umontpellier.iut.encheres.ihm.scenes.MainScene;
import fr.umontpellier.iut.encheres.ihm.scenes.Scenes;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class UserViewController {

    public void loadSignUpView() {
        loadView("signUpView.fxml", "login.css");
    }

    public void loadLoginView() {
        loadView("loginView.fxml", "login.css");
    }

    public void loadMenuTabView(String viewToLoad) {
        MainScene.getMain().setCenter(Scenes.getScene(viewToLoad).getCenterView());
    }

    private void loadView(String view, String css) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/views/"+view));
            Stage currentStage = StageManager.getInstance().getCurrentStage();
            Scene scene = new Scene(loader.load());
            scene.getStylesheets().add(getClass().getResource("/"+css).toExternalForm());
            currentStage.setScene(scene);
            currentStage.show();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

    }

}
